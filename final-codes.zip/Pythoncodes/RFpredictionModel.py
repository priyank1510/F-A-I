import pandas as pd
import matplotlib.pyplot as plt
from xgboost import XGBRegressor
import numpy as np

# Load the dataset
data = pd.read_csv('/Users/kaumudirawal/Desktop/crimeData_clean.csv')

# Convert 'OCCURRED_ON_DATE' to datetime
data['OCCURRED_ON_DATE'] = pd.to_datetime(data['OCCURRED_ON_DATE'])

# Create a new column for Year-Month
data['YEAR_MONTH'] = data['OCCURRED_ON_DATE'].dt.to_period('M')

# Aggregate data to get monthly crime counts by district
monthly_crime_counts = data.groupby(['YEAR_MONTH', 'DISTRICT']).size().reset_index(name='CRIME_COUNT')

# Plotting the crime counts for a specific district
district = 'A1'  # Example district
district_data = monthly_crime_counts[monthly_crime_counts['DISTRICT'] == district]

'''
plt.figure(figsize=(10, 5))
plt.plot(district_data['YEAR_MONTH'].astype(str), district_data['CRIME_COUNT'], marker='o')
plt.title(f'Monthly Crime Counts in District {district}')
plt.xlabel('Year-Month')
plt.ylabel('Crime Count')
plt.xticks(rotation=45)
plt.grid(True)
plt.show()
'''

monthly_crime_counts.to_csv('/Users/kaumudirawal/Desktop/monthly_crime_counts.csv', index=False)

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error

# Load the aggregated data
data = pd.read_csv('/Users/kaumudirawal/Desktop/monthly_crime_counts.csv')
data['YEAR_MONTH'] = pd.to_datetime(data['YEAR_MONTH'].astype(str))

# Convert 'YEAR_MONTH' to period format for monthly granularity
data['YEAR_MONTH'] = data['YEAR_MONTH'].dt.to_period('M')

# Calculate months since the first month in the dataset
start_period = data['YEAR_MONTH'].min()
data['MONTH_SINCE_START'] = data['YEAR_MONTH'].apply(lambda x: (x - start_period).n)

# Prepare the data for modeling
X = data[['MONTH_SINCE_START']]  # Use only numerical month since start
# Encode 'DISTRICT' as categorical and join to X
X = X.join(pd.get_dummies(data['DISTRICT'], prefix='DISTRICT'))
y = data['CRIME_COUNT']

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Initialize and train the model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Predict on the test set
predictions = model.predict(X_test)

# Evaluate the model
mse = mean_squared_error(y_test, predictions)
print("Performance Summary:")
print("\nRandom Forest Metrics:")
print(f'Mean Squared Error: {mse}')

from sklearn.model_selection import GridSearchCV

# Parameters to tune
param_grid = {
    'n_estimators': [50, 100, 200],
    'max_depth': [None, 10, 20, 30],
    'min_samples_split': [2, 5, 10]
}

# Initialize the GridSearchCV  for Random forest object
grid_search = GridSearchCV(estimator=RandomForestRegressor(random_state=42),
                           param_grid=param_grid,
                           cv=3,  # Number of folds in cross-validation
                           scoring='neg_mean_squared_error',
                           verbose=1)

# Fit the grid search to the data
grid_search.fit(X_train, y_train)

# Best parameters and best score
print("Best RF parameters:", grid_search.best_params_)
print("Best RF score (MSE):", -grid_search.best_score_)

'''
import matplotlib.pyplot as plt

feature_importances = pd.Series(model.feature_importances_, index=X_train.columns)
feature_importances.nlargest(10).plot(kind='barh')
plt.title('Top 10 Important Features')
plt.show()
'''
print("\n\n\nPerformance Summary:")
print("\nRandom Forest Metrics:")
print(f"Mean Squared Error: {mse}")
print(f"Root Mean Squared Error: {np.sqrt(mse)}")

# Plot predictions against actual values for RandomForest
plt.figure(figsize=(10, 5))
plt.scatter(y_test, predictions, alpha=0.5, label='RandomForest Predictions')
plt.plot([y.min(), y.max()], [y.min(), y.max()], 'k--', lw=4)
plt.xlabel('Actual')
plt.ylabel('Predicted')
plt.title('Actual vs. Predicted - RandomForest')
plt.legend()
plt.show()


# Initialize the XGBRegressor model
xgb_model = XGBRegressor(n_estimators=100, max_depth=20, learning_rate=0.8, random_state=42)

# Train the model
xgb_model.fit(X_train, y_train)

# Predict on the test set
xgb_predictions = xgb_model.predict(X_test)

print("\nPerformance Summary:")
print("\nXGBoost Regressor:")

# Evaluate the model
xgb_mse = mean_squared_error(y_test, xgb_predictions)
print(f'Mean Squared Error with XGBRegressor: {xgb_mse}')

from sklearn.metrics import mean_absolute_error, r2_score

# Calculate RMSE
rmse = mean_squared_error(y_test, xgb_predictions, squared=False)
print(f'Root Mean Squared Error with XGBRegressor: {rmse}')

# Calculate MAE
mae = mean_absolute_error(y_test, xgb_predictions)
print(f'Mean Absolute Error with XGBRegressor: {mae}')

# Calculate R-squared
r2 = r2_score(y_test, xgb_predictions)
print(f'R-squared with XGBRegressor: {r2}')


from sklearn.svm import SVR

# Initialize and train the SVR model
svr_model = SVR(kernel='rbf')  # The RBF kernel is commonly used, but you can experiment with 'linear', 'poly', etc.
svr_model.fit(X_train, y_train)

# Predict on the test set
svr_predictions = svr_model.predict(X_test)

# Evaluate the model
svr_mse = mean_squared_error(y_test, svr_predictions)
svr_rmse = np.sqrt(svr_mse)
svr_mae = mean_absolute_error(y_test, svr_predictions)
svr_r2 = r2_score(y_test, svr_predictions)

print(f'Support Vector Regression RBF Mean Squared Error: {svr_mse}')
print(f'Support Vector Regression RBF Root Mean Squared Error: {svr_rmse}')
print(f'Support Vector Regression RBF Mean Absolute Error: {svr_mae}')
print(f'Support Vector Regression RBF R-squared: {svr_r2}')



from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GridSearchCV

# Create a pipeline that scales the data then applies SVR
pipeline = make_pipeline(StandardScaler(), SVR(kernel='rbf'))

# Define a grid of parameters to search over
param_grid = {
    'svr__C': [10, 100, 1000],
    'svr__gamma': [0.01, 0.1, 1],
    'svr__epsilon': [1, 5, 10]
}


# Set up the grid search
grid_search = GridSearchCV(pipeline, param_grid, cv=3, scoring='neg_mean_squared_error', verbose=1)

# Fit the grid search to the data
grid_search.fit(X_train, y_train)

# Print out the best parameters
print("\nBest SVR parameters:", grid_search.best_params_)
print("Best SVR score (MSE):", -grid_search.best_score_)

# Use the best estimator to make predictions
best_svr = grid_search.best_estimator_
svr_predictions = best_svr.predict(X_test)

# Re-evaluate the model
svr_mse = mean_squared_error(y_test, svr_predictions)
svr_rmse = np.sqrt(svr_mse)
svr_mae = mean_absolute_error(y_test, svr_predictions)
svr_r2 = r2_score(y_test, svr_predictions)

print(f'2 Support Vector Regression Mean Squared Error: {svr_mse}')
print(f'2 Support Vector Regression Root Mean Squared Error: {svr_rmse}')
print(f'2 Support Vector Regression Mean Absolute Error: {svr_mae}')
print(f'2 Support Vector Regression R-squared: {svr_r2}')


# You can tweak the degree of the polynomial depending on your dataset
# Degree = 3 means a cubic polynomial
pipeline_poly = make_pipeline(StandardScaler(), SVR(kernel='poly', degree=3, C=200, epsilon=15, gamma=0.05))

pipeline_poly.fit(X_train, y_train)

poly_predictions = pipeline_poly.predict(X_test)

poly_mse = mean_squared_error(y_test, poly_predictions)
poly_rmse = np.sqrt(poly_mse)
poly_mae = mean_absolute_error(y_test, poly_predictions)
poly_r2 = r2_score(y_test, poly_predictions)

print(f'Support Vector Regression with Polynomial Kernel Mean Squared Error: {poly_mse}')
print(f'Support Vector Regression with Polynomial Kernel Root Mean Squared Error: {poly_rmse}')
print(f'Support Vector Regression with Polynomial Kernel Mean Absolute Error: {poly_mae}')
print(f'Support Vector Regression with Polynomial Kernel R-squared: {poly_r2}')

#Visualizing the results for Polynomial Kernel SVR
# Plot predictions against actual values for Polynomial Kernel SVR
plt.figure(figsize=(10, 5))
plt.scatter(y_test, poly_predictions, alpha=0.5, color='black', label='SVR Polynomial Predictions')
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'k--', lw=4)  # Diagonal line
plt.xlabel('Actual')
plt.ylabel('Predicted')
plt.title('Actual vs. Predicted - Support Vector Regression with Polynomial Kernel')
plt.legend()
plt.show()

from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

# Create a pipeline that scales the data then applies SVR with a linear kernel
pipeline_linear = make_pipeline(StandardScaler(), SVR(kernel='linear', C=200, epsilon=15))

# Fit the pipeline on the training data
pipeline_linear.fit(X_train, y_train)

# Predict on the test set
linear_predictions = pipeline_linear.predict(X_test)

# Evaluate the model
linear_mse = mean_squared_error(y_test, linear_predictions)
linear_rmse = np.sqrt(linear_mse)
linear_mae = mean_absolute_error(y_test, linear_predictions)
linear_r2 = r2_score(y_test, linear_predictions)

print(f'Support Vector Regression with Linear Kernel Mean Squared Error: {linear_mse}')
print(f'Support Vector Regression with Linear Kernel Root Mean Squared Error: {linear_rmse}')
print(f'Support Vector Regression with Linear Kernel Mean Absolute Error: {linear_mae}')
print(f'Support Vector Regression with Linear Kernel R-squared: {linear_r2}')

#Visualizing the results for Linear Kernel SVR
plt.figure(figsize=(10, 5))
plt.scatter(y_test, linear_predictions, alpha=0.5, color='purple', label='SVR Linear Predictions')
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'k--', lw=4)
plt.xlabel('Actual')
plt.ylabel('Predicted')
plt.title('Actual vs. Predicted - Support Vector Regression with Linear Kernel')
plt.legend()
plt.show()


from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVR
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

# Create a pipeline that scales the data then applies SVR with a sigmoid kernel
pipeline_sigmoid = make_pipeline(StandardScaler(), SVR(kernel='sigmoid', C=200, epsilon=15, gamma=0.05))

# Fit the pipeline on the training data
pipeline_sigmoid.fit(X_train, y_train)

# Predict on the test set
sigmoid_predictions = pipeline_sigmoid.predict(X_test)

# Evaluate the model
sigmoid_mse = mean_squared_error(y_test, sigmoid_predictions)
sigmoid_rmse = np.sqrt(sigmoid_mse)
sigmoid_mae = mean_absolute_error(y_test, sigmoid_predictions)
sigmoid_r2 = r2_score(y_test, sigmoid_predictions)

print(f'Support Vector Regression with Sigmoid Kernel Mean Squared Error: {sigmoid_mse}')
print(f'Support Vector Regression with Sigmoid Kernel Root Mean Squared Error: {sigmoid_rmse}')
print(f'Support Vector Regression with Sigmoid Kernel Mean Absolute Error: {sigmoid_mae}')
print(f'Support Vector Regression with Sigmoid Kernel R-squared: {sigmoid_r2}')

# Visualizing the results for Sigmoid Kernel SVR
plt.figure(figsize=(10, 5))
plt.scatter(y_test, sigmoid_predictions, alpha=0.5, color='orange', label='SVR Sigmoid Predictions')
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'k--', lw=4)
plt.xlabel('Actual')
plt.ylabel('Predicted')
plt.title('Actual vs. Predicted - Support Vector Regression with Sigmoid Kernel')
plt.legend()
plt.show()



# Visualizing the results for SVR
plt.figure(figsize=(10, 5))
plt.scatter(y_test, svr_predictions, alpha=0.5, color='green', label='SVR Predictions')
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'k--', lw=4)
plt.xlabel('Actual')
plt.ylabel('Predicted')
plt.title('Actual vs. Predicted - Support Vector Regression with RBF Kernel')
plt.legend()
plt.show()



#Plot predictions against actual values for XGBoost
plt.figure(figsize=(10, 5))
plt.scatter(y_test, xgb_predictions, alpha=0.5, color='red', label='XGBoost Predictions')
plt.plot([y.min(), y.max()], [y.min(), y.max()], 'k--', lw=4)
plt.xlabel('Actual')
plt.ylabel('Predicted')
plt.title('Actual vs. Predicted - XGBoost')
plt.legend()
plt.show()

plt.figure(figsize=(10, 5))
plt.scatter(y_test, predictions, alpha=0.5, label='RandomForest Predictions')
plt.scatter(y_test, xgb_predictions, alpha=0.5, color='red', label='XGBoost Predictions')
plt.plot([y_test.min(), y_test.max()], [y_test.min(), y_test.max()], 'k--', lw=4)
plt.xlabel('Actual')
plt.ylabel('Predicted')
plt.title('Actual vs. Predicted - RandomForest vs. XGBoost')
plt.legend()
plt.show()


# Calculate residuals for RandomForest
rf_residuals = y_test - predictions

# Calculate residuals for XGBoost
xgb_residuals = y_test - xgb_predictions

# Plot residuals
# plt.figure(figsize=(10, 5))
# plt.hist(rf_residuals, bins=50, alpha=0.5, label='RandomForest Residuals')
# plt.hist(xgb_residuals, bins=50, alpha=0.5, color='red', label='XGBoost Residuals')
# plt.xlabel('Residual')
# plt.ylabel('Frequency')
# plt.title('Distribution of Residuals')
# plt.legend()
# plt.show()


# Assuming you can extract feature importances from RandomForest and XGBoost
rf_importances = model.feature_importances_
xgb_importances = xgb_model.feature_importances_

# Create a DataFrame for easier plotting
importances_df = pd.DataFrame({
    'Features': X_train.columns,
    'RandomForest': rf_importances,
    'XGBoost': xgb_importances
})

# Plot feature importances
importances_df.set_index('Features').plot(kind='bar', figsize=(12, 6))
plt.title('Feature Importances across Models')
plt.ylabel('Importance')
plt.show()
