import numpy as np
import pandas as pd
from folium import folium
from sklearn import ensemble
from sklearn.cluster import KMeans
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import LabelEncoder
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score
from sklearn.ensemble import RandomForestClassifier, VotingClassifier
from sklearn.metrics import classification_report
import seaborn as sns
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import cross_val_score
from sklearn.preprocessing import RobustScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier

# reading the csv file of the crimes in the boston.
crimeData = pd.read_csv(
    r"C:\Users\patel\Documents\CS-5100 Foundation To Artificial Intelligence\Project-work\Pythoncodes\archive\crime.csv",
    encoding='latin-1')
# datatype of the crime data
print("file of the crime data: ", type(crimeData))
# reading  the first 10 files of the csv.
print(crimeData.head(10))
# reading the offense of crimes.
offense = pd.read_csv(
    r"C:\Users\patel\Documents\CS-5100 Foundation To Artificial Intelligence\Project-work\Pythoncodes\archive\offense_codes.csv",
    encoding='latin-1')
# reading the first 10 files of the head of the
print(offense.head(10))
# description of the data of the crimes in the boston.
print(crimeData.describe())
# description of the offense code in the boston.
print(offense.describe())

# checking the data types of the csv file.
print(crimeData.dtypes)

# Total columns in the crime data
columns = crimeData.columns
print("The columns of the crime data: \n", columns)

# Total number of crimes in each district
district_crime = crimeData['DISTRICT'].value_counts()
print("The total number of crimes in each district: \n", district_crime)

# Performing Exploratory Data Analysis
nullCount = crimeData.isnull().sum()
print("The values of the csv that are null: \n", nullCount)

# checking the shape of the csv file.
print("The shape of the data: ", crimeData.shape)

# Drop rows where 'DISTRICT' is NaN
crimeNormalData = crimeData.dropna(subset=['DISTRICT'])

# checking the description of the data.
print(crimeNormalData.describe())

# checking the null count after the drop of the data.
nullCount = crimeNormalData.isnull().sum()
print("The values of the csv that are null: \n", nullCount)

# Drop rows where 'DISTRICT' is NaN
crimeNormalData = crimeNormalData.dropna(subset=['DISTRICT'])

# checking the description of the data.
print(crimeNormalData.describe())

# Fill missing values for 'UCR_PART' and 'STREET' with mode
for column in ['UCR_PART', 'STREET']:
    crimeNormalData[column].fillna(crimeNormalData[column].mode()[0], inplace=True)

# Drop rows where 'STREET' is NaN
crimeNormalData = crimeNormalData.dropna(subset=['STREET'])

# checking the description of the data.
print(crimeNormalData.describe())

# drop the location as lat and long is already given.
crimeNormalData = crimeNormalData.drop('Location', axis=1)
# now checking the description of the data.
print(crimeNormalData.describe())
# checking whether the location is dropped or not.
print(crimeNormalData.columns)

# checking the null count after the drop of the data.
nullCount = crimeNormalData.isnull().sum()
print("The values of the csv that are null: \n", nullCount)

# Fill missing values for 'Lat' and 'Long' with mean
# for column in ['Lat', 'Long']:
#     crimeNormalData[column].fillna(crimeNormalData[column].mean(), inplace=True)

# Drop rows where 'Lat' and 'Long' are null
crimeNormalData = crimeNormalData.dropna(subset=['Lat', 'Long'])
# Replace NaN values with 0 in 'SHOOTING' column
crimeNormalData['SHOOTING'].fillna(0, inplace=True)
# Replace 'Y' with 1.4 in 'SHOOTING' column
crimeNormalData['SHOOTING'].replace('Y', 1, inplace=True)
# checking the null values of the data.
nullCount = crimeNormalData.isnull().sum()
print("The values of the csv that are null: \n", nullCount)
# converting categorical data to numerical data.
value_count = crimeNormalData['DAY_OF_WEEK'].value_counts()
print("The value count of the DAY_OF_WEEK: \n", value_count)
# Save the cleaned data to a new CSV file
cleanCrimeData = crimeNormalData.to_csv('crimeData_clean.csv', index=False)
# Create a dictionary to map days of the week to numerical values
days_mapping = {'Monday': 1, 'Tuesday': 2, 'Wednesday': 3, 'Thursday': 4, 'Friday': 5, 'Saturday': 6, 'Sunday': 7}
# Use the map function to replace the days of the week with numerical values
crimeNormalData['DAY_OF_WEEK'] = crimeNormalData['DAY_OF_WEEK'].map(days_mapping)
# Print some data.
print(crimeNormalData['DAY_OF_WEEK'].head())
# Create a dictionary to map UCR_PART to numerical values
ucr_mapping = {'Part One': 1, 'Part Two': 2, 'Part Three': 3}
# Use the map function to replace the UCR_PART with numerical values
crimeNormalData['UCR_PART'] = crimeNormalData['UCR_PART'].map(ucr_mapping)
# Print some data.
print(crimeNormalData['UCR_PART'].head())
# checking the shape of the csv file.
print("The shape of the data: ", crimeNormalData.shape)

# checking the null values of the data.
nullCount = crimeNormalData.isnull().sum()
print("The values of the csv that are null: \n", nullCount)

# Create a label encoder
encode = LabelEncoder()
# Fit and transform the 'OFFENSE_CODE_GROUP' column
crimeNormalData['OFFENSE_CODE_GROUP'] = encode.fit_transform(crimeNormalData['OFFENSE_CODE_GROUP'])
crimeNormalData['OFFENSE_DESCRIPTION'] = encode.fit_transform(crimeNormalData['OFFENSE_DESCRIPTION'])
crimeNormalData['INCIDENT_NUMBER'] = encode.fit_transform(crimeNormalData['INCIDENT_NUMBER'])
crimeNormalData['OCCURRED_ON_DATE'] = encode.fit_transform(crimeNormalData['OCCURRED_ON_DATE'])
crimeNormalData['DISTRICT'] = encode.fit_transform(crimeNormalData['DISTRICT'])
crimeNormalData['STREET'] = encode.fit_transform(crimeNormalData['STREET'])
# Print the first 5 rows to see the changes
print(crimeNormalData.head())
print(crimeNormalData['OFFENSE_DESCRIPTION'].head())
crimeNormalData.replace(' ', np.nan, inplace=True)
# Drop the rows where at least one element is missing.
crimeNormalData.dropna(inplace=True)
# now we will save the normalized data into the csv file so that it can be used for the further analysis.
# In the Machine Learning models.
newCrimeData = crimeNormalData.to_csv('crimeData_normal.csv', index=False)

# load the initial data
# crimeData = pd.read_csv('archive\crime.csv')
# load the cleaned data
crimeCleanData = pd.read_csv('crimeData_clean.csv')
# Load the cleaned and normalized data
crimeNormalData = pd.read_csv('crimeData_normal.csv')

# label encoding
encode = LabelEncoder()
crimeCleanData['OFFENSE_CODE_GROUP'] = encode.fit_transform(crimeCleanData['OFFENSE_CODE_GROUP'])
crimeCleanData['OFFENSE_DESCRIPTION'] = encode.fit_transform(crimeCleanData['OFFENSE_DESCRIPTION'])
crimeCleanData['INCIDENT_NUMBER'] = encode.fit_transform(crimeCleanData['INCIDENT_NUMBER'])
crimeCleanData['OCCURRED_ON_DATE'] = encode.fit_transform(crimeCleanData['OCCURRED_ON_DATE'])
crimeCleanData['DISTRICT'] = encode.fit_transform(crimeCleanData['DISTRICT'])
crimeCleanData['STREET'] = encode.fit_transform(crimeCleanData['STREET'])
days_mapping = {'Monday': 1, 'Tuesday': 2, 'Wednesday': 3, 'Thursday': 4, 'Friday': 5, 'Saturday': 6, 'Sunday': 7}
# Using the map function to replace the days of the week with numerical values
crimeCleanData['DAY_OF_WEEK'] = crimeCleanData['DAY_OF_WEEK'].map(days_mapping)
# Create a dictionary to map UCR_PART to numerical values
ucr_mapping = {'Part One': 1, 'Part Two': 2, 'Part Three': 3}
# the map function to replace the UCR_PART with numerical values
crimeCleanData['UCR_PART'] = crimeCleanData['UCR_PART'].map(ucr_mapping)
print("The cleaned data: \n", crimeCleanData.head())
# Standardize the data
scaler = StandardScaler()
crime_data_scaled = scaler.fit_transform(crimeCleanData)
print(crime_data_scaled.head())
# Now your data is ready for machine learning
# Splitting the data into features (X) and target (y)
X = crimeCleanData.drop('OFFENSE_CODE_GROUP', axis=1)
y = crimeCleanData['OFFENSE_CODE_GROUP']
print(crimeCleanData['OCCURRED_ON_DATE'].head())
# feature scaling
scaler = StandardScaler()
crime_data_scaled = scaler.fit_transform(crimeCleanData)
# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=20)
# Choose a machine learning model
model = KMeans(n_clusters=4, random_state=20)
# Training the model with the training data
model.fit(X_train, y_train)
# Make predictions now have a trained model
predictions = model.predict(X_test)
accuracy = accuracy_score(y_test, predictions)
print(f"Model Accuracy: {accuracy}")

# Chooseing a machine learning model for classification
clf = RandomForestClassifier(n_estimators=100, random_state=20)
# Training the model with the training data
clf.fit(X_train, y_train)
# Making predictions
predictions = clf.predict(X_test)
# Evaluating the model with the testing data
print(classification_report(y_test, predictions))
# Choose a machine learning model for clustering
model = KMeans(n_clusters=4, random_state=20)
# Training the model with the training data
model.fit(X_train)
# Making predictions
predictions = model.predict(X_test)
# Adding  the predictions to your dataframe
X_test['cluster'] = predictions
# Print the first few rows of your dataframe to see the clusters
print(X_test.head())

cm = confusion_matrix(y_test, predictions)

# Converting the confusion matrix to a dataframe
cm_crimeCleanData = pd.DataFrame(cm)

# Visualizing the confusion matrix using a heatmap
plt.figure(figsize=(10, 7))
sns.heatmap(cm_crimeCleanData, annot=True, fmt='g')
plt.title('Confusion matrix of the classifier')
plt.xlabel('Predicted')
plt.ylabel('True')
plt.show()

print("unique district :", crimeCleanData['DISTRICT'].unique())
# Defining the parameter grid
param_grid = {
    'n_estimators': [100, 200, 300, 400, 500],
    'max_depth': [None, 10, 20, 30, 40, 50],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'bootstrap': [True, False]
}

# Creating a RandomForestClassifier
clf = RandomForestClassifier()

# Creating a GridSearchCV object
grid_search = GridSearchCV(estimator=clf, param_grid=param_grid, cv=5, n_jobs=-1)

# Fitting the GridSearchCV object to the data
grid_search.fit(X_train, y_train)

# Getting the best parameters
best_params = grid_search.best_params_

# Creating a RandomForestClassifier with the best parameters
clf = RandomForestClassifier(**best_params)

# Fitting the model to the data
clf.fit(X_train, y_train)

# Making predictions
predictions = clf.predict(X_test)

# Evaluating the model
print(classification_report(y_test, predictions))

# Performing  cross-validation
scores = cross_val_score(clf, X, y, cv=5)
print(f"Cross-Validation Accuracy Scores: {scores}")

import matplotlib.pyplot as plt
import pandas as pd
from sklearn.cluster import KMeans

# Loading the normalized data
normalized_data = pd.read_csv('crimeData_normalized.csv')

# Taking a sample of 20,000
sample_data = normalized_data.sample(n=2000)

# Grouping the sample data by district
grouped_data = sample_data.groupby('DISTRICT')

# Creating a scatter plot for each district
plt.figure(figsize=(10, 6))
for name, group in grouped_data:
    plt.scatter(group['Long'], group['Lat'], label=f'District {name}', alpha=0.5)

plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.title('Scatter Plot of Crime Locations by District')
plt.legend(title='District', markerscale=2)
plt.show()

# Performing clustering based on the district of crime
from sklearn.cluster import KMeans

# Extracting the district column
districts = sample_data[['Lat', 'Long']]

# Creating a KMeans object with 12 clusters
kmeans = KMeans(n_clusters=12)

# Fitting the model to the data
kmeans.fit(districts)

# Getting the cluster labels
labels = kmeans.labels_

# Plotting the clusters
plt.figure(figsize=(10, 6))
for i, (name, group) in enumerate(grouped_data):
    plt.scatter(group['Long'], group['Lat'], label=f'District {name}', alpha=0.5, marker=f'${i}$')

# Plotting the centroids
plt.scatter(kmeans.cluster_centers_[:, 1], kmeans.cluster_centers_[:, 0], marker='x', s=100, c='red', label='Centroids')

plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.title('Clustered Crime Locations by District')
plt.legend(title='District', markerscale=2)
plt.show()

# Assigning cluster labels to each data point
sample_data['Cluster'] = kmeans.labels_

# Grouping data by cluster
grouped_data = sample_data.groupby('Cluster')

# Initializing dictionaries to store the offense description with maximum count in each cluster
max_count_offense = {}
max_count = {}

# Looping through each cluster
for cluster, data in grouped_data:
    offense_counts = data['OFFENSE_DESCRIPTION'].value_counts()
    # Getting the offense description with maximum count
    max_count_offense[cluster] = offense_counts.idxmax()
    # Getting the maximum count
    max_count[cluster] = offense_counts.max()

plt.figure(figsize=(10, 6))
plt.bar(max_count_offense.keys(), max_count.values())
plt.xlabel('Cluster')
plt.ylabel('Count of Maximum Crime')
plt.title('Count of Maximum Crime in Each Cluster')
plt.xticks(range(len(max_count_offense)), sorted(max_count_offense.keys()))
plt.legend(title='District', markerscale=2)
plt.show()

# # Load the data from the file
data = pd.read_csv('crimeData_normalized.csv')
#
# # Encode categorical variables
# le = LabelEncoder()
# data['UCR_PART'] = le.fit_transform(data['UCR_PART'])
#

# Splitting data into features and target
X = data.drop('UCR_PART', axis=1)
y = data['UCR_PART']

# Splitting data into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Initializing individual models
knn = KNeighborsClassifier()
dt = DecisionTreeClassifier()
svm = SVC()
nb = GaussianNB()
# Train individual models
knn.fit(X_train, y_train)
dt.fit(X_train, y_train)
svm.fit(X_train, y_train)
nb.fit(X_train, y_train)
# Initialize Voting Classifier
ensemble = VotingClassifier(estimators=[('knn', knn), ('dt', dt), ('svm', svm), ('nb', nb)], voting='hard')
ensemble.fit(X_train, y_train)
y_pred_ensemble = ensemble.predict(X_test)
accuracy = accuracy_score(y_test, y_pred_ensemble)
f1 = f1_score(y_test, y_pred_ensemble, average='macro')
print(f'Ensemble Accuracy: {accuracy}')
print(f'Ensemble F1-Score: {f1}')

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import VotingClassifier
from sklearn.model_selection import train_test_split

# Load the data
data = pd.read_csv('crimeData_normalized.csv')
X = data.drop('UCR_PART', axis=1)
y = data['UCR_PART']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
# Initialize individual models
knn = KNeighborsClassifier()
dt = DecisionTreeClassifier()
svm = SVC()
nb = GaussianNB()
# Training individual models
knn.fit(X_train, y_train)
dt.fit(X_train, y_train)
svm.fit(X_train, y_train)
nb.fit(X_train, y_train)

# Initializing Voting Classifier
ensemble = VotingClassifier(estimators=[('knn', knn), ('dt', dt), ('svm', svm), ('nb', nb)], voting='hard')
ensemble.fit(X_train, y_train)
y_pred_ensemble = ensemble.predict(X_test)
cm = confusion_matrix(y_test, y_pred_ensemble)
cm_df = pd.DataFrame(cm, index=sorted(data['UCR_PART'].unique()), columns=sorted(data['UCR_PART'].unique()))
plt.figure(figsize=(10, 7))
sns.heatmap(cm_df, annot=True, cmap='Blues')
plt.title('Confusion Matrix for Crime Severity Prediction')
plt.xlabel('Predicted UCR_PART')
plt.ylabel('True UCR_PART')
plt.show()
# Evaluating ensemble model
accuracy = accuracy_score(y_test, y_pred_ensemble)
f1 = f1_score(y_test, y_pred_ensemble, average='macro')
print(f'Ensemble Accuracy: {accuracy}')
print(f'Ensemble F1-Score: {f1}')

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, accuracy_score, f1_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.ensemble import VotingClassifier
from sklearn.model_selection import train_test_split

data = pd.read_csv('crimeData_normalized.csv')

X = data.drop('UCR_PART', axis=1)
y = data['UCR_PART']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

knn = KNeighborsClassifier()
dt = DecisionTreeClassifier()
svm = SVC()
nb = GaussianNB()

knn.fit(X_train, y_train)
dt.fit(X_train, y_train)
svm.fit(X_train, y_train)
nb.fit(X_train, y_train)

ensemble = VotingClassifier(estimators=[('knn', knn), ('dt', dt), ('svm', svm), ('nb', nb)], voting='hard')
ensemble.fit(X_train, y_train)

# Making predictions on test data
y_pred_ensemble = ensemble.predict(X_test)

# Generating confusion matrix
cm = confusion_matrix(y_test, y_pred_ensemble)

# Creating a DataFrame from the confusion matrix
cm_df = pd.DataFrame(cm, index=sorted(data['UCR_PART'].unique()), columns=sorted(data['UCR_PART'].unique()))

# Plotting the confusion matrix
plt.figure(figsize=(10, 7))
sns.heatmap(cm_df, annot=True, cmap='Blues')
plt.title('Confusion Matrix for Crime Severity Prediction')
plt.xlabel('Predicted UCR_PART')
plt.ylabel('True UCR_PART')
plt.show()

# Evaluating ensemble model
accuracy = accuracy_score(y_test, y_pred_ensemble)
f1 = f1_score(y_test, y_pred_ensemble, average='macro')
print(f'Ensemble Accuracy: {accuracy}')
print(f'Ensemble F1-Score: {f1}')
# Converting UCR_PART to string type
data['UCR_PART'] = data['UCR_PART'].astype(str)
# Calculating classification report
report = classification_report(y_test, y_pred_ensemble, target_names=sorted(data['UCR_PART'].unique()))
# Printing classification report
print("Classification Report:\n", report)

from sklearn.ensemble import VotingClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, accuracy_score, f1_score, classification_report
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB

# Loading the data
data = pd.read_csv('crimeData_normalized.csv')

# Splitting data into features and target
X = data.drop('UCR_PART', axis=1)
y = data['UCR_PART']

# Splitting data into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Initializing individual models
knn = KNeighborsClassifier()
dt = DecisionTreeClassifier()
svm = SVC(probability=True)
nb = GaussianNB()
knn.fit(X_train, y_train)
dt.fit(X_train, y_train)
svm.fit(X_train, y_train)
nb.fit(X_train, y_train)

# Initializing Voting Classifier with weights
ensemble = VotingClassifier(estimators=[('knn', knn), ('dt', dt), ('svm', svm), ('nb', nb)],
                            voting='soft',
                            weights=[1, 0.5, 1, 1])

# Training ensemble model
ensemble.fit(X_train, y_train)

# Making predictions on test data
y_pred_ensemble = ensemble.predict(X_test)
cm = confusion_matrix(y_test, y_pred_ensemble)
cm_df = pd.DataFrame(cm, index=sorted(data['UCR_PART'].unique()), columns=sorted(data['UCR_PART'].unique()))

plt.figure(figsize=(10, 7))
sns.heatmap(cm_df, annot=True, cmap='Blues')
plt.title('Confusion Matrix for Crime Severity Prediction (Ensemble)')
plt.xlabel('Predicted UCR_PART')
plt.ylabel('True UCR_PART')
plt.show()

accuracy = accuracy_score(y_test, y_pred_ensemble)
f1 = f1_score(y_test, y_pred_ensemble, average='macro')
print(f'Ensemble Accuracy: {accuracy}')
print(f'Ensemble F1-Score: {f1}')

# Classification Report for Ensemble Model
report = classification_report(y_test, y_pred_ensemble, target_names=sorted(data['UCR_PART'].unique()))
print("Ensemble Model Classification Report:")
print(report)
models = [('KNN', knn), ('Decision Tree', dt), ('SVM', svm), ('Naive Bayes', nb)]

for name, model in models:
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred, average='macro')
    print(f"{name} Model:")
    print(f"Accuracy: {accuracy}")
    print(f"F1-Score: {f1}")
    print("-" * 20)

    # Classification Report for Individual Models
    report = classification_report(y_test, y_pred, target_names=sorted(data['UCR_PART'].unique()))
    print(f"{name} Model Classification Report:")
    print(report)
