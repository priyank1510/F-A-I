# import pandas as pd
# from sklearn.cluster import KMeans, DBSCAN
# import folium
# from folium.plugins import MarkerCluster
#

# crime_data = pd.read_csv('crimeData_clean.csv')
#

# sample_size = 50000
# crime_data_sample = crime_data.sample(n=sample_size, random_state=42)

# crime_data_sample = crime_data_sample.dropna(subset=['Lat', 'Long'])
# crime_data_sample = crime_data_sample[['Lat', 'Long', 'OCCURRED_ON_DATE', 'DISTRICT', 'OFFENSE_DESCRIPTION']]

# crime_data_sample['HOUR'] = pd.to_datetime(crime_data_sample['OCCURRED_ON_DATE']).dt.hour
# daytime_slots = range(7, 19)  # Daytime: 7 AM to 6:59 PM
# nighttime_slots = list(range(19, 24)) + list(range(0, 7))  # Nighttime: 7 PM to 6:59 AM
# daytime_crimes = crime_data_sample[crime_data_sample['HOUR'].isin(daytime_slots)]
# nighttime_crimes = crime_data_sample[crime_data_sample['HOUR'].isin(nighttime_slots)]
# total_daytime_crimes = len(daytime_crimes)
# total_nighttime_crimes = len(nighttime_crimes)
# print("Total daytime crimes:", total_daytime_crimes)
# print("Total nighttime crimes:", total_nighttime_crimes)
# kmeans_daytime = KMeans(n_clusters=12, random_state=42).fit(daytime_crimes[['Lat', 'Long']])
# daytime_crimes['Cluster_Label_KMeans'] = kmeans_daytime.labels_
# dbscan_nighttime = DBSCAN(eps=0.001, min_samples=5).fit(nighttime_crimes[['Lat', 'Long']])
# nighttime_crimes['Cluster_Label_DBSCAN'] = dbscan_nighttime.labels_
# daytime_map = folium.Map(location=[42.3601, -71.0589], zoom_start=12)
# daytime_marker_clusters = {district: MarkerCluster().add_to(daytime_map) for district in crime_data_sample['DISTRICT'].unique()}
# for idx, row in daytime_crimes.iterrows():
#     cluster_label = row['Cluster_Label_KMeans']
#     district = row['DISTRICT']
#     total_cluster_crimes = len(daytime_crimes[(daytime_crimes['DISTRICT'] == district) & (daytime_crimes['Cluster_Label_KMeans'] == cluster_label)])
#     folium.Marker(
#         location=[row['Lat'], row['Long']],
#         popup=f"District: {district}, Offense Description: {row['OFFENSE_DESCRIPTION']}, Cluster: {cluster_label}, Total Crimes: {total_cluster_crimes}",
#     ).add_to(daytime_marker_clusters[district])
# for district, count in daytime_crimes['DISTRICT'].value_counts().head().items():
#     district_data = daytime_crimes[daytime_crimes['DISTRICT'] == district].iloc[0]  # Take the first data point
#     folium.Marker(
#         location=[district_data['Lat'], district_data['Long']],
#         icon=folium.Icon(color='red', icon='star'),
#         popup=f"Top 5 Crime Area - District: {district}, Total Crimes: {count}"
#     ).add_to(daytime_map)
#
# daytime_map.save('daytime_crime_map.html')
# nighttime_map = folium.Map(location=[42.3601, -71.0589], zoom_start=12)
# nighttime_marker_clusters = {district: MarkerCluster().add_to(nighttime_map) for district in crime_data_sample['DISTRICT'].unique()}
# for idx, row in nighttime_crimes.iterrows():
#     cluster_label = row['Cluster_Label_DBSCAN']
#     district = row['DISTRICT']
#     total_cluster_crimes = len(nighttime_crimes[(nighttime_crimes['DISTRICT'] == district) & (nighttime_crimes['Cluster_Label_DBSCAN'] == cluster_label)])
#     folium.Marker(
#         location=[row['Lat'], row['Long']],
#         popup=f"District: {district}, Offense Description: {row['OFFENSE_DESCRIPTION']}, Cluster: {cluster_label}, Total Crimes: {total_cluster_crimes}",
#     ).add_to(nighttime_marker_clusters[district])
# for district, count in nighttime_crimes['DISTRICT'].value_counts().head().items():
#     district_data = nighttime_crimes[nighttime_crimes['DISTRICT'] == district].iloc[0]
#     folium.Marker(
#         location=[district_data['Lat'], district_data['Long']],
#         icon=folium.Icon(color='red', icon='star'),
#         popup=f"Top 5 Crime Area - District: {district}, Total Crimes: {count}"
#     ).add_to(nighttime_map)
# nighttime_map.save('nighttime_crime_map.html')
# top_daytime_crimes = daytime_crimes['OFFENSE_DESCRIPTION'].value_counts().head(10)
# top_nighttime_crimes = nighttime_crimes['OFFENSE_DESCRIPTION'].value_counts().head(10)
# print("\nTop 10 daytime crimes:\n", top_daytime_crimes)
# print("\nTop 10 nighttime crimes:\n", top_nighttime_crimes)
# max_daytime_cluster = daytime_crimes['DISTRICT'].value_counts().idxmax()
# max_nighttime_cluster = nighttime_crimes['DISTRICT'].value_counts().idxmax()
# print("\nCluster with the maximum number of daytime crimes:", max_daytime_cluster)
# print("Cluster with the maximum number of nighttime crimes:", max_nighttime_cluster)






# import pandas as pd
# from sklearn.cluster import KMeans, DBSCAN
# import folium
# from folium.plugins import MarkerCluster
# crime_data = pd.read_csv('crimeData_clean.csv')
# sample_size = 50000
# crime_data_sample = crime_data.sample(n=sample_size, random_state=42)
# crime_data_sample = crime_data_sample.dropna(subset=['Lat', 'Long'])  # Remove rows with missing latitude and longitude
# crime_data_sample = crime_data_sample[['Lat', 'Long', 'OCCURRED_ON_DATE', 'DISTRICT', 'OFFENSE_DESCRIPTION']]  # Select relevant features
# crime_data_sample['HOUR'] = pd.to_datetime(crime_data_sample['OCCURRED_ON_DATE']).dt.hour
# daytime_slots = range(7, 19)  # Daytime: 7 AM to 6:59 PM
# nighttime_slots = list(range(19, 24)) + list(range(0, 7))  # Nighttime: 7 PM to 6:59 AM
# daytime_crimes = crime_data_sample[crime_data_sample['HOUR'].isin(daytime_slots)]
# nighttime_crimes = crime_data_sample[crime_data_sample['HOUR'].isin(nighttime_slots)]
# kmeans_daytime = KMeans(n_clusters=12, random_state=42).fit(daytime_crimes[['Lat', 'Long']])
# daytime_crimes['Cluster_Label_KMeans'] = kmeans_daytime.labels_
# dbscan_nighttime = DBSCAN(eps=0.001, min_samples=5).fit(nighttime_crimes[['Lat', 'Long']])
# nighttime_crimes['Cluster_Label_DBSCAN'] = dbscan_nighttime.labels_
# daytime_map = folium.Map(location=[42.3601, -71.0589], zoom_start=12)
# daytime_marker_clusters = {district: MarkerCluster().add_to(daytime_map) for district in crime_data_sample['DISTRICT'].unique()}
# for idx, row in daytime_crimes.iterrows():
#     cluster_label = row['Cluster_Label_KMeans']
#     district = row['DISTRICT']
#     total_cluster_crimes = len(daytime_crimes[(daytime_crimes['DISTRICT'] == district) & (daytime_crimes['Cluster_Label_KMeans'] == cluster_label)])
#     color = 'red' if total_cluster_crimes > 50 else ('yellow' if total_cluster_crimes > 20 else 'blue')  # Determine color based on risk level
#     folium.Marker(
#         location=[row['Lat'], row['Long']],
#         popup=f"District: {district}, Offense Description: {row['OFFENSE_DESCRIPTION']}, Cluster: {cluster_label}, Total Crimes: {total_cluster_crimes}",
#         icon=folium.Icon(color=color)
#     ).add_to(daytime_marker_clusters[district])
# for district, count in daytime_crimes['DISTRICT'].value_counts().head().items():
#     district_data = daytime_crimes[daytime_crimes['DISTRICT'] == district].iloc[0]
#     folium.Marker(
#         location=[district_data['Lat'], district_data['Long']],
#         icon=folium.Icon(color='red', icon='star'),
#         popup=f"Top 5 Crime Area - District: {district}, Total Crimes: {count}"
#     ).add_to(daytime_map)
# daytime_map.save('daytime_crime_map.html')
# nighttime_map = folium.Map(location=[42.3601, -71.0589], zoom_start=12)
# nighttime_marker_clusters = {district: MarkerCluster().add_to(nighttime_map) for district in crime_data_sample['DISTRICT'].unique()
# for idx, row in nighttime_crimes.iterrows():
#     cluster_label = row['Cluster_Label_DBSCAN']
#     district = row['DISTRICT']
#     total_cluster_crimes = len(nighttime_crimes[(nighttime_crimes['DISTRICT'] == district) & (nighttime_crimes['Cluster_Label_DBSCAN'] == cluster_label)])
#     color = 'red' if total_cluster_crimes > 50 else ('yellow' if total_cluster_crimes > 20 else 'blue')  # Determine color based on risk level
#     folium.Marker(
#         location=[row['Lat'], row['Long']],
#         popup=f"District: {district}, Offense Description: {row['OFFENSE_DESCRIPTION']}, Cluster: {cluster_label}, Total Crimes: {total_cluster_crimes}",
#         icon=folium.Icon(color=color)
#     ).add_to(nighttime_marker_clusters[district])
# for district, count in nighttime_crimes['DISTRICT'].value_counts().head().items():
#     district_data = nighttime_crimes[nighttime_crimes['DISTRICT'] == district].iloc[0]
#     folium.Marker(
#         location=[district_data['Lat'], district_data['Long']],
#         icon=folium.Icon(color='red', icon='star'),
#         popup=f"Top 5 Crime Area - District: {district}, Total Crimes: {count}"
#     ).add_to(nighttime_map)
# nighttime_map.save('nighttime_crime_map.html')
# top_daytime_crimes = daytime_crimes['OFFENSE_DESCRIPTION'].value_counts().head(10)
# top_nighttime_crimes = nighttime_crimes['OFFENSE_DESCRIPTION'].value_counts().head(10)
# print("\nTop 10 daytime crimes:\n", top_daytime_crimes)
# print("\nTop 10 nighttime crimes:\n", top_nighttime_crimes)
# max_daytime_cluster = daytime_crimes['DISTRICT'].value_counts().idxmax()
# max_nighttime_cluster = nighttime_crimes['DISTRICT'].value_counts().idxmax()
# print("\nCluster with the maximum number of daytime crimes:", max_daytime_cluster)
# print("Cluster with the maximum number of nighttime crimes:", max_nighttime_cluster)
#
#




import pandas as pd
from sklearn.cluster import KMeans
import folium
from folium.plugins import MarkerCluster
# Load data
crime_data = pd.read_csv('crimeData_clean.csv')
# Sampling data
sample_size = 50000
crime_data_sample = crime_data.sample(n=sample_size, random_state=42)
#data preprocessing
crime_data = crime_data.dropna(subset=['Lat', 'Long', 'DISTRICT'])
crime_data['OCCURRED_ON_DATE'] = pd.to_datetime(crime_data['OCCURRED_ON_DATE'])
crime_data['HOUR'] = crime_data['OCCURRED_ON_DATE'].dt.hour
crime_data['DAY'] = crime_data['OCCURRED_ON_DATE'].dt.day
crime_data['MONTH'] = crime_data['OCCURRED_ON_DATE'].dt.month
crime_data['DISTRICT'] = crime_data['DISTRICT'].astype(str)  # Convert DISTRICT to string

daytime_slots = range(7, 19)  # Daytime: 7 AM to 6:59 PM
nighttime_slots = list(range(19, 24)) + list(range(0, 7))  # Nighttime: 7 PM to 6:59 AM

# Splitting data into daytime and nighttime crimes
daytime_crimes = crime_data[crime_data['HOUR'].isin(daytime_slots)]
nighttime_crimes = crime_data[crime_data['HOUR'].isin(nighttime_slots)]
# Performing K-Means clustering on daytime crimes
kmeans_daytime = KMeans(n_clusters=10, random_state=42)  # Adjust the number of clusters as needed
daytime_crimes['Cluster'] = kmeans_daytime.fit_predict(daytime_crimes[['Lat', 'Long', 'DAY', 'MONTH']])

# Performing K-Means clustering on nighttime crimes
kmeans_nighttime = KMeans(n_clusters=12, random_state=42)  # Adjust the number of clusters as needed
nighttime_crimes['Cluster'] = kmeans_nighttime.fit_predict(nighttime_crimes[['Lat', 'Long', 'DAY', 'MONTH']])

# Categorizing districts based on overall crime rates
crime_rate_categories = pd.cut(crime_data['DISTRICT'].value_counts(), bins=3, labels=['High', 'Mid', 'Low'])

# Getting districts in each category
high_crime_districts = crime_rate_categories[crime_rate_categories == 'High'].index.tolist()
mid_crime_districts = crime_rate_categories[crime_rate_categories == 'Mid'].index.tolist()
low_crime_districts = crime_rate_categories[crime_rate_categories == 'Low'].index.tolist()

# Creating a map
crime_map = folium.Map(location=[crime_data['Lat'].mean(), crime_data['Long'].mean()], zoom_start=12)

def assign_color(district):
    if district in high_crime_districts:
        return 'red'
    elif district in mid_crime_districts:
        return 'blue'
    elif district in low_crime_districts:
        return 'lightyellow'
    else:
        return 'gray'

# Creating feature groups for daytime and nighttime clusters
daytime_cluster_group = folium.FeatureGroup(name='Daytime Clusters')
nighttime_cluster_group = folium.FeatureGroup(name='Nighttime Clusters')

# Adding markers for daytime crime clusters
for idx, row in daytime_crimes.iterrows():
    folium.CircleMarker(location=[row['Lat'], row['Long']],
                        radius=5,
                        color='black',
                        fill_color=assign_color(row['DISTRICT']),
                        fill_opacity=0.7,
                        popup=f"Daytime Cluster: {row['Cluster']}, District: {row['DISTRICT']}, Offense Description: {row['OFFENSE_DESCRIPTION']}"
                        ).add_to(daytime_cluster_group)

# Adding markers for nighttime crime clusters
for idx, row in nighttime_crimes.iterrows():
    folium.CircleMarker(location=[row['Lat'], row['Long']],
                        radius=5,
                        color='black',
                        fill_color=assign_color(row['DISTRICT']),
                        fill_opacity=0.7,
                        popup=f"Nighttime Cluster: {row['Cluster']}, District: {row['DISTRICT']}, Offense Description: {row['OFFENSE_DESCRIPTION']}"
                        ).add_to(nighttime_cluster_group)

# Adding layers for high, mid, and low-risk districts
high_risk_layer = folium.FeatureGroup(name='High Risk')
mid_risk_layer = folium.FeatureGroup(name='Mid Risk')
low_risk_layer = folium.FeatureGroup(name='Low Risk')

# Adding markers for high-risk districts
for district in high_crime_districts:
    district_data = crime_data[crime_data['DISTRICT'] == district]
    for idx, row in district_data.iterrows():
        folium.Marker(location=[row['Lat'], row['Long']],
                      icon=folium.Icon(color='red'),
                      popup=f"District: {row['DISTRICT']}"
                      ).add_to(high_risk_layer)

# Adding markers for mid-risk districts
for district in mid_crime_districts:
    district_data = crime_data[crime_data['DISTRICT'] == district]
    for idx, row in district_data.iterrows():
        folium.Marker(location=[row['Lat'], row['Long']],
                      icon=folium.Icon(color='blue'),
                      popup=f"District: {row['DISTRICT']}"
                      ).add_to(mid_risk_layer)

# Adding markers for low-risk districts
for district in low_crime_districts:
    district_data = crime_data[crime_data['DISTRICT'] == district]
    for idx, row in district_data.iterrows():
        folium.Marker(location=[row['Lat'], row['Long']],
                      icon=folium.Icon(color='lightyellow'),
                      popup=f"District: {row['DISTRICT']}"
                      ).add_to(low_risk_layer)

# Adding feature groups to the map
daytime_cluster_group.add_to(crime_map)
nighttime_cluster_group.add_to(crime_map)
high_risk_layer.add_to(crime_map)
mid_risk_layer.add_to(crime_map)
low_risk_layer.add_to(crime_map)

# Adding layer control to the map
folium.LayerControl().add_to(crime_map)

# Saving the map
crime_map.save('crime_map_with_risk_and_clusters.html')












