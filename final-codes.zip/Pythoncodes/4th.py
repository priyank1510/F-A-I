# trail-1
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
import folium
from folium.plugins import MarkerCluster
from collections import Counter

# Load the crime data
crime_data = pd.read_csv('crimeData_clean.csv')

# Taking a random sample of the data
sample_size = 50000
crime_data_sample = crime_data.sample(n=sample_size, random_state=42)

# Data preprocessing
crime_data_sample = crime_data_sample.dropna(subset=['Lat', 'Long', 'DISTRICT'])
crime_data_sample = crime_data_sample[['Lat', 'Long', 'DISTRICT', 'OFFENSE_DESCRIPTION']]

# Resetting the index after filtering
crime_data_sample.reset_index(drop=True, inplace=True)

# Checking  the unique districts in the sample
unique_districts = crime_data_sample['DISTRICT'].unique()
print("Unique districts in the sample:", unique_districts)

# Checking  the number of data points for each district
district_counts = crime_data_sample['DISTRICT'].value_counts()
print("Number of data points for each district:")
print(district_counts)

# Performing  clustering using KMeans
kmeans = KMeans(n_clusters=12, random_state=32).fit(crime_data_sample[['Lat', 'Long']])
crime_data_sample['Cluster_Label'] = kmeans.labels_

# Calculating centroid of each cluster
cluster_centers = kmeans.cluster_centers_

# Getting top 5 most common crimes in each district
district_crimes = {}
for district, group in crime_data_sample.groupby('DISTRICT'):
    top_crimes = group['OFFENSE_DESCRIPTION'].value_counts().head().index.tolist()
    if len(top_crimes) < 5:
        # If fewer than 5 crimes, include all crimes for the district
        all_crimes = group['OFFENSE_DESCRIPTION'].unique().tolist()
        district_crimes[district] = all_crimes
    else:
        district_crimes[district] = top_crimes

# Printing  the top crimes for each district
print("Top crimes for each district:")
for district, crimes in district_crimes.items():
    print(f"{district}: {crimes}")

# a map centered around Boston
crime_map = folium.Map(location=[42.3601, -71.0589], zoom_start=12)

# centroid of each cluster to the map
for idx, center in enumerate(cluster_centers):
    folium.Marker(
        location=[center[0], center[1]],
        popup=f"Cluster {idx}",
        icon=folium.Icon(color='green', icon='info-sign')
    ).add_to(crime_map)

#  top crimes in each district as labels to the centroid
for district in unique_districts:  # Considering all unique districts
    crimes = district_crimes.get(district, [])
    if district in district_counts:
        centroid_idx = crime_data_sample.index[crime_data_sample['DISTRICT'] == district][0]
        centroid = crime_data_sample.loc[centroid_idx, ['Lat', 'Long']]
        popup_content = f"<b>{district}</b><br>"
        for crime in crimes:
            popup_content += f"- {crime}<br>"
        folium.Marker(
            location=[centroid['Lat'], centroid['Long']],
            popup=folium.Popup(popup_content, max_width=300),
            icon=folium.Icon(color='red', icon='star')
        ).add_to(crime_map)

# Saving the hotspot map.
crime_map.save('crime_hotspots_map.html')

# trail-2
# Loading the crime data
crime_data = pd.read_csv('crimeData_clean.csv')

sample_size = 50000
crime_data_sample = crime_data.sample(n=sample_size, random_state=42)

# Data preprocessing
crime_data_sample = crime_data_sample.dropna(subset=['Lat', 'Long', 'DISTRICT'])
# Removing rows with missing latitude, longitude, or district
crime_data_sample = crime_data_sample[['Lat', 'Long', 'DISTRICT', 'OFFENSE_DESCRIPTION']]

# Reset index after filtering
crime_data_sample.reset_index(drop=True, inplace=True)

# Check the unique districts in the sample
unique_districts = crime_data_sample['DISTRICT'].unique()
print("Unique districts in the sample:", unique_districts)

# Check the number of data points for each district
district_counts = crime_data_sample['DISTRICT'].value_counts()
print("Number of data points for each district:")
print(district_counts)

# Performing  clustering using KMeans
kmeans = KMeans(n_clusters=12, random_state=32).fit(crime_data_sample[['Lat', 'Long']])
crime_data_sample['Cluster_Label'] = kmeans.labels_

# Calculating  centroid of each cluster.
cluster_centers = kmeans.cluster_centers_

# Getting top 5 most common crimes in each district.
district_crimes = {}
for district, group in crime_data_sample.groupby('DISTRICT'):
    top_crimes = group['OFFENSE_DESCRIPTION'].value_counts().head().index.tolist()
    if len(top_crimes) < 5:
        # If fewer than 5 crimes, include all crimes for the district
        all_crimes = group['OFFENSE_DESCRIPTION'].unique().tolist()
        district_crimes[district] = all_crimes
    else:
        district_crimes[district] = top_crimes

print("Top crimes for each district:")
for district, crimes in district_crimes.items():
    print(f"{district}: {crimes}")

# creating the map around Boston
crime_map = folium.Map(location=[42.3601, -71.0589], zoom_start=12)

# Adding  centroid of each cluster to the map
for idx, center in enumerate(cluster_centers):
    folium.Marker(
        location=[center[0], center[1]],
        popup=f"Cluster {idx}",
        icon=folium.Icon(color='green', icon='info-sign')
    ).add_to(crime_map)

# Adding top crimes in each district as labels to the centroid
for district in unique_districts:  # Considering all unique districts
    crimes = district_crimes.get(district, [])
    if district in district_counts:
        centroid_idx = crime_data_sample.index[crime_data_sample['DISTRICT'] == district][0]
        centroid = crime_data_sample.loc[centroid_idx, ['Lat', 'Long']]  # adding position of one of the crime points.
        popup_content = f"<b>{district}</b><br>"
        for crime in crimes:
            popup_content += f"- {crime}<br>"
        folium.Marker(
            location=[centroid['Lat'], centroid['Long']],
            popup=folium.Popup(popup_content, max_width=300),
            icon=folium.Icon(color='red', icon='star')
        ).add_to(crime_map)

# saving the map
crime_map.save('crime_hotspots_map.html')
