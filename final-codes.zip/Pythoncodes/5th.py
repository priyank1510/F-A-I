import pandas as pd
from sklearn.cluster import KMeans
import folium
from folium.plugins import MarkerCluster, HeatMap
import pandas as pd
from sklearn.cluster import KMeans
import folium
from folium.plugins import MarkerCluster
import numpy as np
from scipy.stats import gaussian_kde

# Loading the crime data
crime_data = pd.read_csv('crimeData_clean.csv')

sample_size = 2000
crime_data_sample = crime_data.sample(n=sample_size, random_state=42)

# Data preprocessing
crime_data_sample = crime_data_sample.dropna(subset=['Lat', 'Long', 'DISTRICT'])
crime_data_sample = crime_data_sample[['Lat', 'Long', 'DISTRICT', 'OFFENSE_DESCRIPTION']]
crime_data_sample.reset_index(drop=True, inplace=True)

# Performing clustering using KMeans
kmeans = KMeans(n_clusters=12, random_state=32).fit(crime_data_sample[['Lat', 'Long']])
crime_data_sample['Cluster_Label'] = kmeans.labels_

# Getting top 5 most common crimes in each district
district_crimes = {}
for district, group in crime_data_sample.groupby('DISTRICT'):
    top_crimes = group['OFFENSE_DESCRIPTION'].value_counts().nlargest(5).index.tolist()
    district_crimes[district] = top_crimes

# Creating a map centered around Boston
crime_map = folium.Map(location=[42.3601, -71.0589], zoom_start=12)

#  risk categorization
total_districts = crime_data_sample['DISTRICT'].value_counts()
high_risk_threshold = total_districts.quantile(0.66)
low_risk_threshold = total_districts.quantile(0.33)

# Feature groups for each risk level and a default layer
high_risk_layer = folium.FeatureGroup(name='High Risk', show=False)
mid_risk_layer = folium.FeatureGroup(name='Mid Risk', show=False)
low_risk_layer = folium.FeatureGroup(name='Low Risk')

# each crime point with cluster information to the appropriate layer
for index, row in crime_data_sample.iterrows():
    district = row['DISTRICT']
    crime = row['OFFENSE_DESCRIPTION']
    cluster = row['Cluster_Label']
    #  popup including top 5 crimes and current crime
    top_crimes_list = "<br>".join(district_crimes[district])
    popup_content = f"District: {district}<br>Top Crimes:<br>{top_crimes_list}<br>Current Crime: {crime}<br>Cluster: {cluster}"

    if total_districts[district] > high_risk_threshold:
        color = 'red'
    elif total_districts[district] > low_risk_threshold:
        color = 'orange'
    else:
        color = 'blue'

    marker = folium.Marker(
        location=[row['Lat'], row['Long']],
        popup=popup_content,
        icon=folium.Icon(color=color, icon='info-sign')
    )

    if total_districts[district] > high_risk_threshold:
        marker.add_to(high_risk_layer)
    elif total_districts[district] > low_risk_threshold:
        marker.add_to(mid_risk_layer)
    else:
        marker.add_to(low_risk_layer)

for idx, center in enumerate(kmeans.cluster_centers_):
    folium.Marker(
        location=[center[0], center[1]],
        popup=f"Cluster {idx}",
        icon=folium.Icon(color='black', icon='star')
    ).add_to(crime_map)

# Adding each layer to the map
crime_map.add_child(high_risk_layer)
crime_map.add_child(mid_risk_layer)
crime_map.add_child(low_risk_layer)

# Adding Layer control
folium.LayerControl().add_to(crime_map)

# save the map been created.
crime_map.save('crime_hotspots_map.html')

# Filter out outliers by quantile
lower_quantile = crime_data_sample.quantile(0.01)
upper_quantile = crime_data_sample.quantile(0.99)

filtered_data = crime_data_sample[
    (crime_data_sample['Lat'] > lower_quantile['Lat']) & (crime_data_sample['Lat'] < upper_quantile['Lat']) &
    (crime_data_sample['Long'] > lower_quantile['Long']) & (crime_data_sample['Long'] < upper_quantile['Long'])
    ]

# Extract coordinates from filtered data
coords = filtered_data[['Lat', 'Long']].values

# Calculate KDE
kde = gaussian_kde(coords.T)

# Generate grid
x_grid, y_grid = np.mgrid[filtered_data['Lat'].min():filtered_data['Lat'].max():100j,
                 filtered_data['Long'].min():filtered_data['Long'].max():100j]

# Evaluate grid
grid_coords = np.vstack([x_grid.ravel(), y_grid.ravel()])
kde_values = kde(grid_coords)

# Create a map
crime_map = folium.Map(location=[42.3601, -71.0589], zoom_start=12)

# Prepare heatmap data by associating KDE values with coordinates
kde_data = np.column_stack([x_grid.ravel(), y_grid.ravel(), kde_values])

# Add HeatMap
HeatMap(kde_data, radius=20, max_zoom=18, blur=15, gradient={0.4: 'blue', 0.65: 'lime', 1: 'red'}).add_to(crime_map)

# Display and save the map
crime_map.save('kde.html')
