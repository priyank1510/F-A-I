import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import folium
from sklearn.cluster import DBSCAN, KMeans
from sklearn.preprocessing import StandardScaler
from folium.plugins import MarkerCluster
from sklearn.neighbors import KernelDensity
import seaborn as sns
from folium.plugins import HeatMap

# Loading the crime data.
crime_data = pd.read_csv('crimeData_clean.csv')

# taking the random sample of the data.
sample_size = 50000
crime_data_sample = crime_data.sample(n=sample_size, random_state=42)

# Data preprocessing
crime_data_sample = crime_data_sample.dropna(subset=['Lat', 'Long'])
crime_data_sample = crime_data_sample[['Lat', 'Long']]

# Standardizing the data
scaler = StandardScaler()
crime_data_scaled = scaler.fit_transform(crime_data_sample)

# DBSCAN Clustering
dbscan = DBSCAN(eps=0.01, min_samples=10)
dbscan_labels = dbscan.fit_predict(crime_data_scaled)

# K-Means Clustering
kmeans = KMeans(n_clusters=5)
kmeans_labels = kmeans.fit_predict(crime_data_scaled)


# Function for saving teh map with clusters.
def create_map_with_clusters(cluster_labels, method_name):
    # creating the map around boston.
    base_map = folium.Map(location=[42.3601, -71.0589], zoom_start=12)  # Boston coordinates

    # Adding the crime
    for idx, row in crime_data_sample.iterrows():
        lat = row['Lat']
        lon = row['Long']
        folium.CircleMarker([lat, lon], radius=3, color='red').add_to(base_map)

    # adding the clusters in the map.
    cluster_colors = ['green', 'blue', 'purple', 'orange', 'darkred', 'cadetblue', 'lightgreen']
    for label in set(cluster_labels):
        if label != -1:
            cluster_points = crime_data_sample[cluster_labels == label]
            for idx, row in cluster_points.iterrows():
                lat = row['Lat']
                lon = row['Long']
                folium.CircleMarker([lat, lon], radius=3, color=cluster_colors[label % len(cluster_colors)]).add_to(
                    base_map)

    # saving the map.
    base_map.save(f'map_{method_name}.html')


create_map_with_clusters(dbscan_labels, 'DBSCAN')
create_map_with_clusters(kmeans_labels, 'KMeans')

# trial-2


normalized_data = pd.read_csv('crimeData_normalized.csv')
sample_data = normalized_data.sample(n=2000)

# Group the data by district
grouped_data = sample_data.groupby('DISTRICT')

# creating the scatter plot.
plt.figure(figsize=(10, 6))
for name, group in grouped_data:
    plt.scatter(group['Long'], group['Lat'], label=name, alpha=0.5)

plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.title('Scatter Plot of Crime Locations by District')
plt.legend(title='District', markerscale=2)
plt.show()

# Performing  clustering based on the district of crime

# extracting the latitude and longitude columns
districts = sample_data[['Lat', 'Long']]

# Creating a KMeans object with 12 clusters
kmeans = KMeans(n_clusters=12)

# Fitting the model.
kmeans.fit(districts)

# Getting the cluster labels
labels = kmeans.labels_

# plotting the clusters.
plt.figure(figsize=(10, 6))
for name, group in grouped_data:
    plt.scatter(group['Long'], group['Lat'], label=name, alpha=0.5)

# plotting the centriods.
plt.scatter(kmeans.cluster_centers_[:, 1], kmeans.cluster_centers_[:, 0], marker='x', s=100, c='red', label='Centroids')

plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.title('Clustered Crime Locations by District')
plt.legend(title='District', markerscale=2)
plt.show()

# Loading the crime data
crime_data = pd.read_csv('crimeData_clean.csv')
sample_size = 50000
crime_data_sample = crime_data.sample(n=sample_size, random_state=42)

# Data preprocessing
crime_data_sample = crime_data_sample.dropna(subset=['Lat', 'Long'])
crime_data_sample = crime_data_sample[['Lat', 'Long']]
district_names = ['D14', 'C11', 'D4', 'B3', 'B2', 'C6', 'A1', 'E5', 'A7', 'E13', 'E18', 'A15']

# DBSCAN Clustering
dbscan = DBSCAN(eps=0.01, min_samples=20)
dbscan_labels = dbscan.fit_predict(crime_data_sample)

# K-Means Clustering
kmeans = KMeans(n_clusters=5)
kmeans_labels = kmeans.fit_predict(crime_data_sample)


# Function to create and save map
def create_map_with_clusters(cluster_labels, method_name):
    # Creating a base map centered on Boston
    base_map = folium.Map(location=[42.3601, -71.0589], zoom_start=12)  # Boston coordinates

    # Adding crime locations to the map
    for idx, row in crime_data_sample.iterrows():
        lat = row['Lat']
        lon = row['Long']
        folium.CircleMarker([lat, lon], radius=3, color='red').add_to(base_map)

    # Adding clusters to the map
    cluster_colors = ['green', 'blue', 'purple', 'orange', 'darkred', 'cadetblue', 'lightgreen']
    for label in set(cluster_labels):
        if label != -1:
            cluster_points = crime_data_sample[cluster_labels == label]
            for idx, row in cluster_points.iterrows():
                lat = row['Lat']
                lon = row['Long']
                folium.CircleMarker([lat, lon], radius=3, color=cluster_colors[label % len(cluster_colors)]).add_to(
                    base_map)

    # Saving the map.
    base_map.save(f'map_{method_name}.html')


# Generating and save maps with clusters for DBSCAN and K-Means
create_map_with_clusters(dbscan_labels, 'DBSCAN')
create_map_with_clusters(kmeans_labels, 'KMeans')

# trail-3
normalized_data = pd.read_csv('crimeData_clean.csv')

# Takin a sample of 100000
sample_data = normalized_data.sample(n=100000)

# Performing clustering based on the district of crime
districts = sample_data[['Lat', 'Long']]

# Creating a KMeans object with 12 clusters
kmeans = KMeans(n_clusters=12)

# Fitting the model to the data
kmeans.fit(districts)

# Adding cluster labels to the sample data
sample_data['Cluster'] = kmeans.labels_

# Converting 'Cluster' column to integer
sample_data['Cluster'] = sample_data['Cluster'].astype(int)

# creating the map around boston.
crime_map = folium.Map(location=[42.3601, -71.0589], zoom_start=12)

# creating the m
marker_clusters = [MarkerCluster().add_to(crime_map) for _ in range(12)]

# Adding crime locations to MarkerClusters
for idx, row in sample_data.iterrows():
    folium.Marker(
        location=[row['Lat'], row['Long']],
        popup=f"Cluster: {district_names[row['Cluster']]}, Offense Description: {row['OFFENSE_DESCRIPTION']}"
    ).add_to(marker_clusters[row['Cluster']])

crime_map.save('crime_map1.html')

# trail-4
crime_data = pd.read_csv('crimeData_clean.csv')

sample_size = 50000
crime_data_sample = crime_data.sample(n=sample_size, random_state=42)

# Data preprocessing
crime_data_sample = crime_data_sample.dropna(subset=['Lat', 'Long'])
crime_data_sample = crime_data_sample[['Lat', 'Long', 'OCCURRED_ON_DATE', 'DISTRICT', 'OFFENSE_DESCRIPTION']]

#  district names
district_names = ['D14', 'C11', 'D4', 'B3', 'B2', 'C6', 'A1', 'E5', 'A7', 'E13', 'E18', 'A15']

#  hour from OCCURRED_ON_DATE column
crime_data_sample['HOUR'] = pd.to_datetime(crime_data_sample['OCCURRED_ON_DATE']).dt.hour

# time
daytime_slots = range(7, 19)  # Daytime: 7 AM to 6:59 PM
nighttime_slots = list(range(19, 24)) + list(range(0, 7))  # Nighttime: 7 PM to 6:59 AM

# Splitting data into daytime and nighttime crimes
daytime_crimes = crime_data_sample[crime_data_sample['HOUR'].isin(daytime_slots)]
nighttime_crimes = crime_data_sample[crime_data_sample['HOUR'].isin(nighttime_slots)]

# Calculating total number of daytime and nighttime crimes
total_daytime_crimes = len(daytime_crimes)
total_nighttime_crimes = len(nighttime_crimes)

print("Total daytime crimes:", total_daytime_crimes)
print("Total nighttime crimes:", total_nighttime_crimes)

# Createing a map centered around Boston for daytime crimes
daytime_map = folium.Map(location=[42.3601, -71.0589], zoom_start=12)

# Creating MarkerCluster for each district
daytime_marker_clusters = [MarkerCluster().add_to(daytime_map) for _ in range(12)]

# Adding  daytime crime locations to MarkerClusters
for idx, row in daytime_crimes.iterrows():
    folium.Marker(
        location=[row['Lat'], row['Long']],
        popup=f"District: {row['DISTRICT']}, Offense Description: {row['OFFENSE_DESCRIPTION']}"
    ).add_to(daytime_marker_clusters[district_names.index(row['DISTRICT'])])

# Save the daytime map
daytime_map.save('daytime_crime_map.html')

# Creating a map centered around Boston for nighttime crimes
nighttime_map = folium.Map(location=[42.3601, -71.0589], zoom_start=12)

# Creating MarkerCluster for each district
nighttime_marker_clusters = [MarkerCluster().add_to(nighttime_map) for _ in range(12)]

# Adding nighttime crime locations to MarkerClusters
for idx, row in nighttime_crimes.iterrows():
    folium.Marker(
        location=[row['Lat'], row['Long']],
        popup=f"District: {row['DISTRICT']}, Offense Description: {row['OFFENSE_DESCRIPTION']}"
    ).add_to(nighttime_marker_clusters[district_names.index(row['DISTRICT'])])

# Saving the nighttime map
nighttime_map.save('nighttime_crime_map.html')

# trail-5
# Data preprocessing
crime_data = crime_data.dropna(subset=['Lat', 'Long', 'DISTRICT'])
crime_data['OCCURRED_ON_DATE'] = pd.to_datetime(crime_data['OCCURRED_ON_DATE'])

crime_data['HOUR'] = crime_data['OCCURRED_ON_DATE'].dt.hour
crime_data['DISTRICT'] = crime_data['DISTRICT'].astype(str)

#  time
daytime_slots = range(7, 19)  # Daytime: 7 AM to 6:59 PM
nighttime_slots = list(range(19, 24)) + list(range(0, 7))  # Nighttime: 7 PM to 6:59 AM

# Splitting data into daytime and nighttime crimes
daytime_crimes = crime_data[crime_data['HOUR'].isin(daytime_slots)]
nighttime_crimes = crime_data[crime_data['HOUR'].isin(nighttime_slots)]

# Performing the  K-Means clustering on daytime crimes
kmeans_daytime = KMeans(n_clusters=10, random_state=42)
daytime_crimes['Cluster'] = kmeans_daytime.fit_predict(daytime_crimes[['Lat', 'Long']])

daytime_clusters = daytime_crimes.groupby('Cluster')
for cluster_id, cluster_data in daytime_clusters:
    print(f"\nCluster {cluster_id}:")
    print("Most common crime in this cluster:")
    print(cluster_data['OFFENSE_DESCRIPTION'].value_counts().head(1))
    print("Most common district for crimes in this cluster:")
    print(cluster_data['DISTRICT'].value_counts().head(1))

# Performing K-Means clustering on nighttime crimes
kmeans_nighttime = KMeans(n_clusters=12, random_state=42)
nighttime_crimes['Cluster'] = kmeans_nighttime.fit_predict(nighttime_crimes[['Lat', 'Long']])

# Analyzing nighttime crime clusters
nighttime_clusters = nighttime_crimes.groupby('Cluster')
for cluster_id, cluster_data in nighttime_clusters:
    print(f"\nCluster {cluster_id}:")
    print("Most common crime in this cluster:")
    top_crime = cluster_data['OFFENSE_DESCRIPTION'].value_counts().head(1)
    if not top_crime.empty:
        print(top_crime)
    else:
        print("No offense descriptions available for this cluster.")
    print("Most common district for crimes in this cluster:")
    print(cluster_data['DISTRICT'].value_counts().head(1))

# crime patterns
overall_crimes = crime_data.groupby(['OFFENSE_DESCRIPTION', 'DISTRICT'])[
    'OCCURRED_ON_DATE'].count().reset_index().sort_values(['OCCURRED_ON_DATE'], ascending=False)
print("\nOverall most common crime types and districts:")
print(overall_crimes.head(10))

# Visualizing the daytime crime clusters on a map
daytime_map = folium.Map(location=[crime_data['Lat'].mean(), crime_data['Long'].mean()], zoom_start=12)
daytime_marker_clusters = [MarkerCluster().add_to(daytime_map) for _ in range(kmeans_daytime.n_clusters)]

for idx, row in daytime_crimes.iterrows():
    folium.Marker(
        location=[row['Lat'], row['Long']],
        popup=f"Cluster: {row['Cluster']}, District: {row['DISTRICT']}, Offense Description: {row['OFFENSE_DESCRIPTION']}"
    ).add_to(daytime_marker_clusters[row['Cluster']])

daytime_map.save('daytime_crime_clusters.html')

# Visualizing  nighttime crime clusters on a map
nighttime_map = folium.Map(location=[crime_data['Lat'].mean(), crime_data['Long'].mean()], zoom_start=12)
nighttime_marker_clusters = [MarkerCluster().add_to(nighttime_map) for _ in range(kmeans_nighttime.n_clusters)]

for idx, row in nighttime_crimes.iterrows():
    folium.Marker(
        location=[row['Lat'], row['Long']],
        popup=f"Cluster: {row['Cluster']}, District: {row['DISTRICT']}, Offense Description: {row['OFFENSE_DESCRIPTION']}"
    ).add_to(nighttime_marker_clusters[row['Cluster']])

nighttime_map.save('nighttime_crime_clusters.html')

# Providing recommendations based on the analysis
print("\nRecommendations:")
print("Based on the analysis, the following areas or districts might be advisable to avoid:")
high_risk_districts = overall_crimes['DISTRICT'].value_counts().head(3).index.tolist()
print(f"- {', '.join(high_risk_districts)} (due to overall high crime rates)")

high_risk_nighttime_clusters = nighttime_clusters.apply(
    lambda x: x['OFFENSE_DESCRIPTION'].value_counts().index[0] if not x[
        'OFFENSE_DESCRIPTION'].value_counts().empty else '').value_counts().head(2).index.tolist()
high_risk_crimes = [crime for crime in high_risk_nighttime_clusters if crime != '']
print(
    f"- Areas around nighttime crime clusters {', '.join(map(str, high_risk_nighttime_clusters))} (due to high rates of {', '.join(high_risk_crimes)})")

# trail-7
crime_data = pd.read_csv(
    r'C:\Users\patel\Documents\CS-5100 Foundation To Artificial Intelligence\Project-work\Pythoncodes\crimeData_clean.csv')

# Data preprocessing
heat_crime_map = folium.Map(location=[crime_data['Lat'].mean(), crime_data['Long'].mean()], zoom_start=12)

# latitude and longitude data
crime_locations = crime_data[['Lat', 'Long']].values.tolist()

# heatmap layer
heatmap_layer = HeatMap(crime_locations, radius=15)

# Adding the heatmap layer to the map
heatmap_layer.add_to(heat_crime_map)

# Displaying the map
heat_crime_map
heat_crime_map.save('heat_crime_map1.html')

#  the occurrences of each crime type
crime_type_counts = crime_data['OFFENSE_DESCRIPTION'].value_counts()

# Printing  the top 10 most common crime types
print("Top 10 Most Common Crime Types:")
print(crime_type_counts.head(10))

# Analyzing crime types within a specific district
district_of_interest = 'D14'
district_crimes = crime_data[crime_data['DISTRICT'] == district_of_interest]
district_crime_types = district_crimes['OFFENSE_DESCRIPTION'].value_counts()

print(f"\nTop Crime Types in District {district_of_interest}:")
print(district_crime_types.head(10))

# Analyzing crime types within a specific district
district_of_interest = 'D14'
district_crimes = crime_data[crime_data['DISTRICT'] == district_of_interest]
district_crime_types = district_crimes['OFFENSE_DESCRIPTION'].value_counts()

print(f"\nTop Crime Types in District {district_of_interest}:")
print(district_crime_types.head(10))

# Analyzing  crime types within a specific district
district_of_interest = 'D14'
district_crimes = crime_data[crime_data['DISTRICT'] == district_of_interest]
district_crime_types = district_crimes['OFFENSE_DESCRIPTION'].value_counts()

print(f"\nTop Crime Types in District {district_of_interest}:")
print(district_crime_types.head(10))

# Analyzing crime types within a specific district
district_of_interest = 'B2'
district_crimes = crime_data[crime_data['DISTRICT'] == district_of_interest]
district_crime_types = district_crimes['OFFENSE_DESCRIPTION'].value_counts()
print(f"\nTop Crime Types in District {district_of_interest}:")
print(district_crime_types.head(10))

# Analyzing crime types within a specific district
district_of_interest = 'C11'
district_crimes = crime_data[crime_data['DISTRICT'] == district_of_interest]
district_crime_types = district_crimes['OFFENSE_DESCRIPTION'].value_counts()
print(f"\nTop Crime Types in District {district_of_interest}:")
print(district_crime_types.head(10))  # Analyze crime types within a specific district
district_of_interest = 'D14'
district_crimes = crime_data[crime_data['DISTRICT'] == district_of_interest]
district_crime_types = district_crimes['OFFENSE_DESCRIPTION'].value_counts()
print(f"\nTop Crime Types in District {district_of_interest}:")
print(district_crime_types.head(10))

# trial-8
crime_data = pd.read_csv('crimeData_clean.csv')
crime_data = crime_data.dropna(subset=['Lat', 'Long', 'DISTRICT'])
crime_data['OCCURRED_ON_DATE'] = pd.to_datetime(crime_data['OCCURRED_ON_DATE'])

#  hour, day, and month from the data
crime_data['HOUR'] = crime_data['OCCURRED_ON_DATE'].dt.hour
crime_data['DAY'] = crime_data['OCCURRED_ON_DATE'].dt.day
crime_data['MONTH'] = crime_data['OCCURRED_ON_DATE'].dt.month
crime_data['DISTRICT'] = crime_data['DISTRICT'].astype(str)  # Convert DISTRICT to string

#  time
daytime_slots = range(7, 19)  # Daytime: 7 AM to 6:59 PM
nighttime_slots = list(range(19, 24)) + list(range(0, 7))  # Nighttime: 7 PM to 6:59 AM

# Splitting data into daytime and nighttime crimes
daytime_crimes = crime_data[crime_data['HOUR'].isin(daytime_slots)]
nighttime_crimes = crime_data[crime_data['HOUR'].isin(nighttime_slots)]

# Performing  K-Means clustering on daytime crimes
kmeans_daytime = KMeans(n_clusters=10, random_state=42)
daytime_crimes['Cluster'] = kmeans_daytime.fit_predict(daytime_crimes[['Lat', 'Long', 'DAY', 'MONTH']])

# Analyzing  daytime crime clusters
daytime_clusters = daytime_crimes.groupby('Cluster')
for cluster_id, cluster_data in daytime_clusters:
    print(f"\nDaytime Cluster {cluster_id}:")
    print("Most common crime in this cluster:")
    print(cluster_data['OFFENSE_DESCRIPTION'].value_counts().head(1))
    print("Most common district for crimes in this cluster:")
    print(cluster_data['DISTRICT'].value_counts().head(1))

# Performing  K-Means clustering on nighttime crimes
kmeans_nighttime = KMeans(n_clusters=12, random_state=42)
nighttime_crimes['Cluster'] = kmeans_nighttime.fit_predict(nighttime_crimes[['Lat', 'Long', 'DAY', 'MONTH']])

# Analyzing nighttime crime clusters
nighttime_clusters = nighttime_crimes.groupby('Cluster')
for cluster_id, cluster_data in nighttime_clusters:
    print(f"\nNighttime Cluster {cluster_id}:")
    print("Most common crime in this cluster:")
    top_crime = cluster_data['OFFENSE_DESCRIPTION'].value_counts().head(1)
    if not top_crime.empty:
        print(top_crime)
    else:
        print("No offense descriptions available for this cluster.")
    print("Most common district for crimes in this cluster:")
    print(cluster_data['DISTRICT'].value_counts().head(1))

# Visualizing  daytime crime clusters on a map
daytime_map = folium.Map(location=[crime_data['Lat'].mean(), crime_data['Long'].mean()], zoom_start=12)
daytime_marker_clusters = [MarkerCluster().add_to(daytime_map) for _ in range(kmeans_daytime.n_clusters)]

for idx, row in daytime_crimes.iterrows():
    folium.Marker(
        location=[row['Lat'], row['Long']],
        popup=f"Cluster: {row['Cluster']}, District: {row['DISTRICT']}, Offense Description: {row['OFFENSE_DESCRIPTION']}"
    ).add_to(daytime_marker_clusters[row['Cluster']])

daytime_map.save('daytime_crime_clusters2.html')

# Visualizing nighttime crime clusters on a map
nighttime_map = folium.Map(location=[crime_data['Lat'].mean(), crime_data['Long'].mean()], zoom_start=12)
nighttime_marker_clusters = [MarkerCluster().add_to(nighttime_map) for _ in range(kmeans_nighttime.n_clusters)]

for idx, row in nighttime_crimes.iterrows():
    folium.Marker(
        location=[row['Lat'], row['Long']],
        popup=f"Cluster: {row['Cluster']}, District: {row['DISTRICT']}, Offense Description: {row['OFFENSE_DESCRIPTION']}"
    ).add_to(nighttime_marker_clusters[row['Cluster']])

nighttime_map.save('nighttime_crime_clusters2.html')

print("\nRecommendations:")

# Categorizing districts based on overall crime rates
crime_rate_categories = pd.cut(crime_data['DISTRICT'].value_counts(), bins=3, labels=['High', 'Mid', 'Low'])

# Getting the  districts in each category
high_crime_districts = crime_rate_categories[crime_rate_categories == 'High'].index.tolist()
mid_crime_districts = crime_rate_categories[crime_rate_categories == 'Mid'].index.tolist()
low_crime_districts = crime_rate_categories[crime_rate_categories == 'Low'].index.tolist()

print("Areas with High Crime Rates:")
print(", ".join(high_crime_districts))

print("\nAreas with Mid Crime Rates:")
print(", ".join(mid_crime_districts))

print("\nAreas with Low Crime Rates:")
print(", ".join(low_crime_districts))

# trial-9
crime_data = pd.read_csv('crimeData_clean.csv')

# Data preprocessing
crime_data = crime_data.dropna(subset=['Lat', 'Long', 'DISTRICT'])
crime_data['OCCURRED_ON_DATE'] = pd.to_datetime(crime_data['OCCURRED_ON_DATE'])

crime_data['HOUR'] = crime_data['OCCURRED_ON_DATE'].dt.hour
crime_data['DAY'] = crime_data['OCCURRED_ON_DATE'].dt.day
crime_data['MONTH'] = crime_data['OCCURRED_ON_DATE'].dt.month
crime_data['DISTRICT'] = crime_data['DISTRICT'].astype(str)

# time
daytime_slots = range(7, 19)  # Daytime: 7 AM to 6:59 PM
nighttime_slots = list(range(19, 24)) + list(range(0, 7))  # Nighttime: 7 PM to 6:59 AM

# Splitting data into daytime and nighttime crimes
daytime_crimes = crime_data[crime_data['HOUR'].isin(daytime_slots)]
nighttime_crimes = crime_data[crime_data['HOUR'].isin(nighttime_slots)]

# Performing  K-Means clustering on daytime crimes
kmeans_daytime = KMeans(n_clusters=10, random_state=42)
daytime_crimes['Cluster'] = kmeans_daytime.fit_predict(daytime_crimes[['Lat', 'Long', 'DAY', 'MONTH']])

# Performing K-Means clustering on nighttime crimes
kmeans_nighttime = KMeans(n_clusters=12, random_state=42)
nighttime_crimes['Cluster'] = kmeans_nighttime.fit_predict(nighttime_crimes[['Lat', 'Long', 'DAY', 'MONTH']])

# Categorizing districts based on overall crime rates
crime_rate_categories = pd.cut(crime_data['DISTRICT'].value_counts(), bins=3, labels=['High', 'Mid', 'Low'])

# Getting districts in each category
high_crime_districts = crime_rate_categories[crime_rate_categories == 'High'].index.tolist()
mid_crime_districts = crime_rate_categories[crime_rate_categories == 'Mid'].index.tolist()
low_crime_districts = crime_rate_categories[crime_rate_categories == 'Low'].index.tolist()

# Creating a map
crime_map = folium.Map(location=[crime_data['Lat'].mean(), crime_data['Long'].mean()], zoom_start=12)


# for the color of the markers.
def assign_color(district):
    if district in high_crime_districts:
        return 'red'
    elif district in mid_crime_districts:
        return 'blue'
    elif district in low_crime_districts:
        return 'lightyellow'
    else:
        return 'gray'


# adding the markers to the cluster.
for idx, row in daytime_crimes.iterrows():
    folium.CircleMarker(location=[row['Lat'], row['Long']],
                        radius=5,
                        color='black',
                        fill_color=assign_color(row['DISTRICT']),
                        fill_opacity=0.7,
                        popup=f"Daytime Cluster: {row['Cluster']}, District: {row['DISTRICT']}, Offense Description: {row['OFFENSE_DESCRIPTION']}"
                        ).add_to(crime_map)

# Adding the  markers to the nighttime clusters.
for idx, row in nighttime_crimes.iterrows():
    folium.CircleMarker(location=[row['Lat'], row['Long']],
                        radius=5,
                        color='black',
                        fill_color=assign_color(row['DISTRICT']),
                        fill_opacity=0.7,
                        popup=f"Nighttime Cluster: {row['Cluster']}, District: {row['DISTRICT']}, Offense Description: {row['OFFENSE_DESCRIPTION']}"
                        ).add_to(crime_map)

# Adding layers for high, mid, and low-risk districts
high_risk_layer = folium.FeatureGroup(name='High Risk')
mid_risk_layer = folium.FeatureGroup(name='Mid Risk')
low_risk_layer = folium.FeatureGroup(name='Low Risk')

# Adding markers for high-risk districts
for district in high_crime_districts:
    district_data = crime_data[crime_data['DISTRICT'] == district]
    for idx, row in district_data.iterrows():
        folium.Marker(location=[row['Lat'], row['Long']],
                      icon=folium.Icon(color='red'),
                      popup=f"District: {row['DISTRICT']}"
                      ).add_to(high_risk_layer)

# Adding markers for mid-risk districts
for district in mid_crime_districts:
    district_data = crime_data[crime_data['DISTRICT'] == district]
    for idx, row in district_data.iterrows():
        folium.Marker(location=[row['Lat'], row['Long']],
                      icon=folium.Icon(color='blue'),
                      popup=f"District: {row['DISTRICT']}"
                      ).add_to(mid_risk_layer)

# Adding markers for low-risk districts
for district in low_crime_districts:
    district_data = crime_data[crime_data['DISTRICT'] == district]
    for idx, row in district_data.iterrows():
        folium.Marker(location=[row['Lat'], row['Long']],
                      icon=folium.Icon(color='lightyellow'),
                      popup=f"District: {row['DISTRICT']}"
                      ).add_to(low_risk_layer)

# Adding layers to the map
high_risk_layer.add_to(crime_map)
mid_risk_layer.add_to(crime_map)
low_risk_layer.add_to(crime_map)

# Adding layer control to the map
folium.LayerControl().add_to(crime_map)
# saving the map.
crime_map.save('crime_map_with_risk2.html')

# trial-10
crime_data = pd.read_csv('crimeData_clean.csv')
sample_size = 5000
crime_data_sample = crime_data.sample(n=sample_size, random_state=42)

# Data preprocessing
crime_data_sample = crime_data_sample.dropna(subset=['Lat', 'Long', 'DISTRICT'])
crime_data_sample['OCCURRED_ON_DATE'] = pd.to_datetime(crime_data_sample['OCCURRED_ON_DATE'])
crime_data_sample['HOUR'] = crime_data_sample['OCCURRED_ON_DATE'].dt.hour
crime_data_sample['DAY'] = crime_data_sample['OCCURRED_ON_DATE'].dt.day
crime_data_sample['MONTH'] = crime_data_sample['OCCURRED_ON_DATE'].dt.month
crime_data_sample['DISTRICT'] = crime_data_sample['DISTRICT'].astype(str)

#  time
daytime_slots = range(7, 19)  # Daytime: 7 AM to 6:59 PM
nighttime_slots = list(range(19, 24)) + list(range(0, 7))  # Nighttime: 7 PM to 6:59 AM

# Splitting data into daytime and nighttime crimes
daytime_crimes = crime_data_sample[crime_data_sample['HOUR'].isin(daytime_slots)]
nighttime_crimes = crime_data_sample[crime_data_sample['HOUR'].isin(nighttime_slots)]

# Performing K-Means clustering on daytime crimes
kmeans_daytime = KMeans(n_clusters=12, random_state=42)  # Adjust the number of clusters as needed
daytime_crimes['Cluster'] = kmeans_daytime.fit_predict(daytime_crimes[['Lat', 'Long', 'DAY', 'MONTH']])

# Performing K-Means clustering on nighttime crimes
kmeans_nighttime = KMeans(n_clusters=12, random_state=42)  # Adjust the number of clusters as needed
nighttime_crimes['Cluster'] = kmeans_nighttime.fit_predict(nighttime_crimes[['Lat', 'Long', 'DAY', 'MONTH']])

# Categorizing districts based on overall crime rates
crime_rate_categories = pd.cut(crime_data_sample['DISTRICT'].value_counts(), bins=3, labels=['High', 'Mid', 'Low'])

high_crime_districts = crime_rate_categories[crime_rate_categories == 'High'].index.tolist()
mid_crime_districts = crime_rate_categories[crime_rate_categories == 'Mid'].index.tolist()
low_crime_districts = crime_rate_categories[crime_rate_categories == 'Low'].index.tolist()

# Creating a map
crime_map = folium.Map(location=[crime_data_sample['Lat'].mean(), crime_data_sample['Long'].mean()], zoom_start=12)


# giving the color to the markers
def assign_color(district):
    if district in high_crime_districts:
        return 'red'
    elif district in mid_crime_districts:
        return 'blue'
    elif district in low_crime_districts:
        return 'lightyellow'
    else:
        return 'gray'


# Adding markers for daytime crime clusters
for idx, row in daytime_crimes.iterrows():
    folium.CircleMarker(location=[row['Lat'], row['Long']],
                        radius=5,
                        color='black',
                        fill_color=assign_color(row['DISTRICT']),
                        fill_opacity=0.7,
                        popup=f"Daytime Cluster: {row['Cluster']}, District: {row['DISTRICT']}, Offense Description: {row['OFFENSE_DESCRIPTION']}"
                        ).add_to(crime_map)

# Adding markers for nighttime crime clusters
for idx, row in nighttime_crimes.iterrows():
    folium.CircleMarker(location=[row['Lat'], row['Long']],
                        radius=5,
                        color='black',
                        fill_color=assign_color(row['DISTRICT']),
                        fill_opacity=0.7,
                        popup=f"Nighttime Cluster: {row['Cluster']}, District: {row['DISTRICT']}, Offense Description: {row['OFFENSE_DESCRIPTION']}"
                        ).add_to(crime_map)

# Adding layers for high, mid, and low-risk districts
high_risk_layer = folium.FeatureGroup(name='High Risk')
mid_risk_layer = folium.FeatureGroup(name='Mid Risk')
low_risk_layer = folium.FeatureGroup(name='Low Risk')

# Adding markers for high-risk districts
for district in high_crime_districts:
    district_data = crime_data_sample[crime_data_sample['DISTRICT'] == district]
    for idx, row in district_data.iterrows():
        folium.Marker(location=[row['Lat'], row['Long']],
                      icon=folium.Icon(color='red'),
                      popup=f"District: {row['DISTRICT']}"
                      ).add_to(high_risk_layer)

# Adding markers for mid-risk districts
for district in mid_crime_districts:
    district_data = crime_data_sample[crime_data_sample['DISTRICT'] == district]
    for idx, row in district_data.iterrows():
        folium.Marker(location=[row['Lat'], row['Long']],
                      icon=folium.Icon(color='blue'),
                      popup=f"District: {row['DISTRICT']}"
                      ).add_to(mid_risk_layer)

# Adding markers for low-risk districts
for district in low_crime_districts:
    district_data = crime_data_sample[crime_data_sample['DISTRICT'] == district]
    for idx, row in district_data.iterrows():
        folium.Marker(location=[row['Lat'], row['Long']],
                      icon=folium.Icon(color='lightyellow'),
                      popup=f"District: {row['DISTRICT']}"
                      ).add_to(low_risk_layer)

# Adding layers to the map
high_risk_layer.add_to(crime_map)
mid_risk_layer.add_to(crime_map)
low_risk_layer.add_to(crime_map)

# Adding layer control to the map
folium.LayerControl().add_to(crime_map)
crime_map.save('crime_map_with_risk_sample3.html')

# trial-12

crime_data = pd.read_csv('crimeData_clean.csv')

sample_size = 5000
crime_data_sample = crime_data.sample(n=sample_size, random_state=42)

# Filtering  crime data based on offense descriptions like assualt.
assault_shooting = crime_data_sample[crime_data_sample['OFFENSE_DESCRIPTION'].str.contains('ASSAULT|SHOOTING')]
robbery = crime_data_sample[crime_data_sample['OFFENSE_DESCRIPTION'].str.contains('ROBBERY')]
verbal_dispute = crime_data_sample[crime_data_sample['OFFENSE_DESCRIPTION'].str.contains('VERBAL DISPUTE')]

# Counting the occurrences of each offense description by district
assault_shooting_counts = assault_shooting['DISTRICT'].value_counts()
robbery_counts = robbery['DISTRICT'].value_counts()
verbal_dispute_counts = verbal_dispute['DISTRICT'].value_counts()
total_offenses = crime_data_sample['DISTRICT'].value_counts()

# Calculating offense rate for each district
offense_rate = pd.DataFrame({
    'District': total_offenses.index,
    'Assault_Shooting_Rate': assault_shooting_counts / total_offenses,
    'Robbery_Rate': robbery_counts / total_offenses,
    'Verbal_Dispute_Rate': verbal_dispute_counts / total_offenses
}).fillna(0)

# Categorizing districts based on offense rates
offense_rate['Risk_Category'] = pd.cut(offense_rate.mean(axis=1), bins=[0, 0.33, 0.66, 1],
                                       labels=['Low', 'Mid', 'High'])

# Merging offense rates with crime data
crime_data_sample = crime_data_sample.merge(offense_rate, on='District', how='left')

# Data preprocessing
crime_data_sample = crime_data_sample.dropna(subset=['Lat', 'Long', 'DISTRICT'])
crime_data_sample['OCCURRED_ON_DATE'] = pd.to_datetime(crime_data_sample['OCCURRED_ON_DATE'])
crime_map = folium.Map(location=[crime_data_sample['Lat'].mean(), crime_data_sample['Long'].mean()], zoom_start=12)


def assign_color(risk_category):
    if risk_category == 'High':
        return 'red'
    elif risk_category == 'Mid':
        return 'blue'
    elif risk_category == 'Low':
        return 'lightyellow'
    else:
        return 'gray'


# Add markers for crime incidents
for idx, row in crime_data_sample.iterrows():
    folium.CircleMarker(location=[row['Lat'], row['Long']],
                        radius=5,
                        color='black',
                        fill_color=assign_color(row['Risk_Category']),
                        fill_opacity=0.7,
                        popup=f"District: {row['DISTRICT']}, Offense Description: {row['OFFENSE_DESCRIPTION']}"
                        ).add_to(crime_map)

folium.LayerControl().add_to(crime_map)
crime_map.save('crime_map_with_risk5.html')

# trial-13
# Load the crime data
crime_data = pd.read_csv('crimeData_clean.csv')

# Calculating  the number of crimes in each district
crime_counts = crime_data['DISTRICT'].value_counts()

print("Crime Counts by District:")
print(crime_counts)

# Finding  the district with the most crimes
most_crimes_district = crime_counts.idxmax()
most_crimes_count = crime_counts.max()
print(f"\nThe district with the most crimes is {most_crimes_district} with {most_crimes_count} crimes.")

# trial-14
# Load the crime data
crime_data = pd.read_csv('crimeData_clean.csv')
sample_size = 1000
crime_data_sample = crime_data.sample(n=sample_size, random_state=42)

# Filtering  out rows with missing latitude and longitude
crime_data = crime_data_sample.dropna(subset=['Lat', 'Long'])

# Extracting latitude and longitude
X = crime_data[['Lat', 'Long']]

# Fitting Kernel Density Estimation
kde = KernelDensity(bandwidth=0.01, metric='haversine', kernel='gaussian', algorithm='ball_tree')
kde.fit(np.radians(X))

# Create a grid of latitude and longitude points for evaluation
grid_points = np.vstack([X['Lat'], X['Long']]).T

# Evaluate the KDE model on the grid of points
log_density = kde.score_samples(np.radians(grid_points))

# Convert log-density to density
density = np.exp(log_density)

# Adding density as a new column in the DataFrame
crime_data['Density'] = density

# Plotting KDE heatmap
plt.figure(figsize=(10, 8))
sns.scatterplot(x='Long', y='Lat', size='Density', data=crime_data, legend=False, alpha=0.5)
plt.title('Kernel Density Estimation of Crime Distribution')
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.show()

# trial-15
crime_data = pd.read_csv('crimeData_clean.csv')
# Taking a random sample of the data
sample_size = 50000
crime_data_sample = crime_data.sample(n=sample_size, random_state=42)

# Data preprocessing
crime_data_sample = crime_data_sample.dropna(subset=['Lat', 'Long'])
crime_data_sample = crime_data_sample[['Lat', 'Long', 'OCCURRED_ON_DATE', 'DISTRICT', 'OFFENSE_DESCRIPTION']]

#  hour from OCCURRED_ON_DATE column
crime_data_sample['HOUR'] = pd.to_datetime(crime_data_sample['OCCURRED_ON_DATE']).dt.hour

# Defining time slots
daytime_slots = range(7, 19)  # Daytime: 7 AM to 6:59 PM
nighttime_slots = list(range(19, 24)) + list(range(0, 7))  # Nighttime: 7 PM to 6:59 AM

# Splitting data into daytime and nighttime crimes
daytime_crimes = crime_data_sample[crime_data_sample['HOUR'].isin(daytime_slots)]
nighttime_crimes = crime_data_sample[crime_data_sample['HOUR'].isin(nighttime_slots)]

# Performing clustering for daytime crimes using KMeans
kmeans_daytime = KMeans(n_clusters=12, random_state=42).fit(daytime_crimes[['Lat', 'Long']])
daytime_crimes['Cluster_Label_KMeans'] = kmeans_daytime.labels_

# Performing clustering for nighttime crimes using DBSCAN
dbscan_nighttime = DBSCAN(eps=0.001, min_samples=5).fit(nighttime_crimes[['Lat', 'Long']])
nighttime_crimes['Cluster_Label_DBSCAN'] = dbscan_nighttime.labels_

# a map centered around Boston for daytime crimes
daytime_map = folium.Map(location=[42.3601, -71.0589], zoom_start=12)

#  MarkerCluster for each district for daytime crimes
daytime_marker_clusters = {district: MarkerCluster().add_to(daytime_map) for district in
                           crime_data_sample['DISTRICT'].unique()}

#  daytime crime locations to MarkerClusters with cluster information in popup
for idx, row in daytime_crimes.iterrows():
    cluster_label = row['Cluster_Label_KMeans']
    district = row['DISTRICT']
    total_cluster_crimes = len(daytime_crimes[(daytime_crimes['DISTRICT'] == district) & (
                daytime_crimes['Cluster_Label_KMeans'] == cluster_label)])
    color = 'red' if total_cluster_crimes > 50 else ('yellow' if total_cluster_crimes > 20 else 'blue')
    folium.Marker(
        location=[row['Lat'], row['Long']],
        popup=f"District: {district}, Offense Description: {row['OFFENSE_DESCRIPTION']}, Cluster: {cluster_label}, Total Crimes: {total_cluster_crimes}",
        icon=folium.Icon(color=color)
    ).add_to(daytime_marker_clusters[district])

# top 5 daytime crime areas as red stars
for district, count in daytime_crimes['DISTRICT'].value_counts().head().items():
    district_data = daytime_crimes[daytime_crimes['DISTRICT'] == district].iloc[0]  # Take the first data point
    folium.Marker(
        location=[district_data['Lat'], district_data['Long']],
        icon=folium.Icon(color='red', icon='star'),
        popup=f"Top 5 Crime Area - District: {district}, Total Crimes: {count}"
    ).add_to(daytime_map)

daytime_map.save('daytime_crime_map3.html')

#  a map centered around Boston for nighttime crimes
nighttime_map = folium.Map(location=[42.3601, -71.0589], zoom_start=12)

#  MarkerCluster for each district for nighttime crimes
nighttime_marker_clusters = {district: MarkerCluster().add_to(nighttime_map) for district in
                             crime_data_sample['DISTRICT'].unique()}

# nighttime crime locations to MarkerClusters with cluster information in popup
for idx, row in nighttime_crimes.iterrows():
    cluster_label = row['Cluster_Label_DBSCAN']
    district = row['DISTRICT']
    total_cluster_crimes = len(nighttime_crimes[(nighttime_crimes['DISTRICT'] == district) & (
                nighttime_crimes['Cluster_Label_DBSCAN'] == cluster_label)])
    color = 'red' if total_cluster_crimes > 50 else ('yellow' if total_cluster_crimes > 20 else 'blue')
    folium.Marker(
        location=[row['Lat'], row['Long']],
        popup=f"District: {district}, Offense Description: {row['OFFENSE_DESCRIPTION']}, Cluster: {cluster_label}, Total Crimes: {total_cluster_crimes}",
        icon=folium.Icon(color=color)
    ).add_to(nighttime_marker_clusters[district])

#  top 5 nighttime crime areas as red stars
for district, count in nighttime_crimes['DISTRICT'].value_counts().head().items():
    district_data = nighttime_crimes[nighttime_crimes['DISTRICT'] == district].iloc[0]
    folium.Marker(
        location=[district_data['Lat'], district_data['Long']],
        icon=folium.Icon(color='red', icon='star'),
        popup=f"Top 5 Crime Area - District: {district}, Total Crimes: {count}"
    ).add_to(nighttime_map)

nighttime_map.save('nighttime_crime_map3.html')

# Top 10 crimes happening in daytime and nighttime
top_daytime_crimes = daytime_crimes['OFFENSE_DESCRIPTION'].value_counts().head(10)
top_nighttime_crimes = nighttime_crimes['OFFENSE_DESCRIPTION'].value_counts().head(10)

print("\nTop 10 daytime crimes:\n", top_daytime_crimes)
print("\nTop 10 nighttime crimes:\n", top_nighttime_crimes)

# Getting the clusters with the maximum number of crimes
max_daytime_cluster = daytime_crimes['DISTRICT'].value_counts().idxmax()
max_nighttime_cluster = nighttime_crimes['DISTRICT'].value_counts().idxmax()
print("\nCluster with the maximum number of daytime crimes:", max_daytime_cluster)
print("Cluster with the maximum number of nighttime crimes:", max_nighttime_cluster)
